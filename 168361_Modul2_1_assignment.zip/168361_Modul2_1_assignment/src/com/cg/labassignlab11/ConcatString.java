package com.cg.labassignlab11;
public interface ConcatString {
	void concatStringWithSpa(String firstS,String secondS);
}
