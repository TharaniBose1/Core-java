package com.cg.labassignlab11;
import java.util.Scanner;
import java.util.function.Predicate;

import com.cg.labassignlab8.alternate.ThreadA;
public class LambdaExpressAcceptNo {
	public static void main(String[] args) {
		CalculatePow ref1=(num1,num2)-> System.out.println(Math.pow(num1,num2));
		ref1.calCulatePower(4, 2);
        ConcatString ref2= (str1,str2)->System.out.println(str1+"  "+str2);
        ref2.concatStringWithSpa("Tharani", "Bose");
        InterfaceForAuthe ref3= (username,password)->{
        	System.out.println("Enter the username and his respective password!!!");
        	if(username.equals("USER") && password.equals("tharanibose"))
        		return true;
			return false;
        };
      boolean result1=  ref3.validate( "USER","tharanibose");
      System.out.println("The result of validation is"+result1);
      InterfaceForAuthe ref4= (username,password)->{
      	System.out.println("Enter the username and his respective password!!!");
      	if(username.equals("USER") && password.equals("tharanibose"))
      		return true;
			return false;
      };
    boolean result2=  ref4.validate( "USER","tharanibos");
    System.out.println("The result of validation is"+result2);
    FactorialNoInterface ref5=(numb)->{
    	long i,fact=1;  
		  for(i=1;i<=numb;i++)
		      fact=fact*i;    
		return fact;
    };
   long res= ref5.calculateFact(6);
   System.out.println("Factorial value"+res);
   Predicate<Long> check = i -> (i == 720);  
   // Calling Predicate method 
   System.out.println(check.test((long) 720));  
	}
	}


