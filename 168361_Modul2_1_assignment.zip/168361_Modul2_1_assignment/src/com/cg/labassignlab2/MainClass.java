package com.cg.labassignlab2;
public class MainClass {
	public static void main(String[] args) {
		System.out.println("Person Details");
		System.out.println("----------------------------------");
		System.out.println("Enter FirstName,LastName,PhoneNumber,Age,Weight,Gender...");
		try {
			new MethodsToGet().DisplayDetails();
		} catch (firstNameIsNotBlankException e) {
			e.printStackTrace();
		} catch (lastNameIsBlankException e) {
			e.printStackTrace();
		}
	}

}
