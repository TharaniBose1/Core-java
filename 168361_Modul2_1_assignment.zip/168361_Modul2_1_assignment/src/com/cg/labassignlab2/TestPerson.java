package com.cg.labassignlab2;
import static org.junit.Assert.*;
import org.junit.Test;
import com.cg.labassignlabjunittest.Person1;
public class TestPerson {
	@Test
	public void testGetFirstName()
	{
		System.out.println("from TestPerson");
		Person per = new Person("Robert","King","M","983663284",23,56);
		assertEquals("Robert",per.getFirstName());
	}
	@Test
	public void testGetLastName()
	{
		System.out.println("from TestPerson");
		Person per = new Person("Robert","King","M","983663284",23,56);
		assertEquals("King",per.getLastName());;
	}
	@Test
	public void testGetGender()
	{
		System.out.println("from TestPerson");
		Person per = new Person("Robert","King","M","983663284",23,56);
		assertEquals("M",per.getGender());
	}
	@Test
	public void testGetPhoneNumber()
	{
		System.out.println("from TestPerson");
		Person per = new Person("Robert","King","M","9836632814",23,56);
		assertEquals("9836632814",per.getPhoneNumber());
	}
	@Test
	public void testGetAge()
	{
		System.out.println("from TestPerson");
		Person per = new Person("Robert","King","M","983663284",23,56);
		assertEquals(23,per.getAge());
	}
	@Test
	public void testGetWeight()
	{
		System.out.println("from TestPerson");
		Person per = new Person("Robert","King","M","983663284",23,56);
		String expected="56.0";
		String actual=Float.toString(per.getWeight());
		assertEquals(expected, actual);

	}
}
