package com.cg.labassignlab2;
public class firstNameIsNotBlankException extends Exception {

	public firstNameIsNotBlankException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public firstNameIsNotBlankException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public firstNameIsNotBlankException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public firstNameIsNotBlankException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public firstNameIsNotBlankException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
