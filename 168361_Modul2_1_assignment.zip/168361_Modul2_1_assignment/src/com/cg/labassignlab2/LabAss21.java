package com.cg.labassignlab2;
import java.util.Scanner;
public class LabAss21 {
	public static void main(String[] args) {
		System.out.println("Person Details:");
		System.out.println("----------------------------------------------");
		Scanner scan=new Scanner(System.in);
		System.out.print("Enter the First Name :");
		String firstName=scan.nextLine();
		System.out.print("Enter the Last Name :");
		String lastName=scan.nextLine();
		System.out.print("Enter the Gender :");
		String gender=scan.next();
		System.out.print("Enter the Age :");
		int age=scan.nextInt();
		System.out.print("Enter the Weigth:");
		float weight=scan.nextFloat();	
	}
}
