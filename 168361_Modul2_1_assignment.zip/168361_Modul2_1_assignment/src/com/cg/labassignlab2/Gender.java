package com.cg.labassignlab2;
	public enum Gender {
	    M("Male"),
	    F("Female");
		private final String genderName;
	    private Gender(String genderName){
			this.genderName = genderName;
		}
		public  String getGenderName() {
			return genderName;
		}
	}

