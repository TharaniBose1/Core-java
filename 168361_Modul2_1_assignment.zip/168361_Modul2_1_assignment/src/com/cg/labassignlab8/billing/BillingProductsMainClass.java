package com.cg.labassignlab8.billing;
public class BillingProductsMainClass {
	public static void main(String[] args) {
		ResourceForLock lock=new ResourceForLock();
		BillingProducts thread1=new BillingProducts(lock);
		GettingProducts thread2=new GettingProducts(lock);
		thread1.start();
		thread2.start();
		try {
			thread1.join();
			thread2.join();
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
		
	}


}
