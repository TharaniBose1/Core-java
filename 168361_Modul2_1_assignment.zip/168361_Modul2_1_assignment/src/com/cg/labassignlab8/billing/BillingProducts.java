package com.cg.labassignlab8.billing;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class BillingProducts extends Thread {
	ResourceForLock lock;
	public BillingProducts(ResourceForLock lock) {
		super();
		this.lock = lock;
	}
	@Override
	public void run() {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the no of Products");
	 int numberOfProd=scan.nextInt();
		try {
			synchronized (lock) {
				
					while(lock.flag!=1) {
						lock.wait();}
				ArrayList<String>arrayList=new ArrayList<>(numberOfProd);
				for(int i=0;i<numberOfProd;i++) {
					System.out.println("Enter the products to be billed");
						arrayList.add(scan.next());
				}
					System.out.println("Products are"+arrayList);
					Thread.sleep(100);
					lock.flag=2;
					lock.notifyAll();
				}} catch (Exception e) {
					e.printStackTrace();
				}
		super.run();}
	}

