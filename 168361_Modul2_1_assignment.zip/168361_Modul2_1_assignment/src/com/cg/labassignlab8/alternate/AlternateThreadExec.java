package com.cg.labassignlab8.alternate;
public class AlternateThreadExec {
public static void main(String[] args) {
	ResourceLock lock=new ResourceLock();
	ThreadA a=new ThreadA(lock);
	ThreadB b=new ThreadB(lock);
	a.start();
	b.start();
}
}







