package com.cg.labassignlab4;
import static org.junit.Assert.*;
import org.junit.Test;
import com.cg.labassignlab4.*;
public class TestEmployee {
	@Test
	public void testGetAge() throws AgeIsNotAcceptedException
	{
		System.out.println("from TestEmployee");
		Person per = new Person("Tharani",25);
		String expectedage="25";
		String actualage=Integer.toString(per.getAge());
		assertEquals(expectedage,actualage );
	}
	@Test (expected=AgeIsNotAcceptedException.class)
	public void testForInvalidData() throws AgeIsNotAcceptedException
	{
		System.out.println("from TestPerson2 testing exceptions");
		Person per1 = new Person("Tharani",5);
	}

}
