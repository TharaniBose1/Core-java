package com.cg.labassignlab4;
public class AgeIsNotAcceptedException extends Exception {
	public AgeIsNotAcceptedException() {
		super();
	}
	public AgeIsNotAcceptedException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public AgeIsNotAcceptedException(String message, Throwable cause) {
		super(message, cause);
	}

	public AgeIsNotAcceptedException(String message) {
		super(message);
	}

	public AgeIsNotAcceptedException(Throwable cause) {
		super(cause);
	}

}
