package com.cg.labassignlab4;
public class SavingsAccount extends Account {
	Account account;
final double minBalance=500;
	@Override
	public boolean withdraw(double withdrawAmount) {
		if(account.getBalance()>minBalance)
		return super.withdraw(withdrawAmount);
		return false;
	}

}
