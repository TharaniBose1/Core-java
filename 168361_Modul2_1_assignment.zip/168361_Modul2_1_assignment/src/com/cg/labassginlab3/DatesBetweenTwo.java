package com.cg.labassginlab3;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class DatesBetweenTwo {
	public static void main(String[] args) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		   LocalDateTime now = LocalDateTime.now();
		   System.out.println("Please enter date in mentionsed Format: yyyy-MM-dd");
		   Scanner scan=new Scanner(System.in);
		   String dateBeforeString=scan.next() ;//scan from user
		   String dateAfterString = "2019-07-29";
			//Parsing the date
			LocalDate dateBefore = LocalDate.parse(dateBeforeString);
			LocalDate dateAfter = LocalDate.parse(dateAfterString);
				
			//calculating number of days in between
			long noOfDaysBetween1 = ChronoUnit.DAYS.between(dateBefore, now);
			long noOfMonthsBetween1=ChronoUnit.MONTHS.between(dateBefore, now);
			long noOfYearsBetween1=ChronoUnit.YEARS.between(dateBefore, now);
			long noOfDaysBetween2= ChronoUnit.DAYS.between(dateBefore,dateAfter);
			long noOfMonthsBetween2=ChronoUnit.MONTHS.between(dateBefore, dateAfter);
			long noOfYearsBetween2=ChronoUnit.YEARS.between(dateBefore, dateAfter);
				
				
			//displaying the number of days,months,years
			System.out.println(noOfDaysBetween1+"   "+noOfMonthsBetween1+"   "+noOfYearsBetween1);
			System.out.println(noOfDaysBetween2+"   "+noOfMonthsBetween2+"   "+noOfYearsBetween2);


	}
}
