package com.cg.labassginlab3;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class FindingExpiringDate {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.print("Enter the product purchasedDate:     ");
		String purchasedDateString=scan.next();
		System.out.print("Enter the product WarranteePeriod:   ");
		String warranteePeriodString=scan.next();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate purchasedDate=LocalDate.parse(purchasedDateString);
		purchasedDate.format(dtf);
		long warranteePeriod=Integer.parseInt(warranteePeriodString);
		LocalDate expiryDate = purchasedDate.plusYears(warranteePeriod);   
		System.out.println("Product ExpiryDate"+expiryDate);
	}

}
