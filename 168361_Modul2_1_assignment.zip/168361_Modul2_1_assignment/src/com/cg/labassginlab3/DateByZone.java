package com.cg.labassginlab3;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Scanner;
public class DateByZone {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the zone ID to view date and time:  ");
		String zoneId1=scan.next();
			    ZoneId zone1 = ZoneId.of(zoneId1);
			    ZoneId zone2 = ZoneId.of("Brazil/East");
			    LocalDateTime now1 = LocalDateTime.now(zone1);
			    LocalDateTime now2 = LocalDateTime.now(zone2);
			    System.out.println(now1);
			    System.out.println(now2);
			    //System.out.println(now1.isBefore(now2));  // false

			  }
			
	}


