package com.cg.labassignlabjunittest;
import static org.junit.Assert.*;
import org.junit.Test;
public class DateTest {
	@Test
	public void testGetDay()
	{
		System.out.println("from TestDate");
		Date da = new Date(12,12,12);
		assertEquals(12,da.intgetDay());
	}
	@Test
	public void testGetMonth()
	{
		System.out.println("from TestDate");
		Date da = new Date(12,12,12);
		assertEquals(12,da.getMonth());
	}
	@Test
	public void testGetYear()
	{
		System.out.println("from TestDate");
		Date da = new Date(12,12,12);
		assertEquals(12,da.getYear());
	}

}
