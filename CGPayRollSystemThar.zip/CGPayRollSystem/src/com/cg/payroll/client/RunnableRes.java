package com.cg.payroll.client;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.util.PayrollUnit;
public class RunnableRes extends PayrollUnit implements Runnable {
	@Override
	public void run() {
		
		 try
         {
                FileOutputStream fos =
                   new FileOutputStream("D:\\hashmap.txt");
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                oos.writeObject(associates);
                oos.close();
                fos.close();
                System.out.printf("Serialized HashMap data is saved in hashmap.txt");
         }catch(IOException ioe)
          {
                ioe.printStackTrace();
          }
		 
		 
		 
}
		
	}


