public class Address {
private int pinCode;
private String state;
public Address() {
}
public Address(int pinCode, String state) {
	super();
	this.pinCode = pinCode;
	this.state = state;
}
public int getPinCode() {
	return pinCode;
}
public void setPinCode(int pinCode) {
	this.pinCode = pinCode;
}
public String getState() {
	return state;
}

public void setState(String state) {
	this.state = state;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + pinCode;
	result = prime * result + ((state == null) ? 0 : state.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Address other = (Address) obj;
	if (pinCode != other.pinCode)
		return false;
	if (state == null) {
		if (other.state != null)
			return false;
	} else if (!state.equals(other.state))
		return false;
	return true;
}


}
