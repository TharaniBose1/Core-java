package com.cg.attendencesystem.beans;
public class ExamFeeDetails {
private int  penaltyToBePaid,examFeeToPaid,totalExamFeeToPaid;
public ExamFeeDetails() {}
public ExamFeeDetails(int examFeeToPaid) {
	super();
	this.examFeeToPaid = examFeeToPaid;
}
public int getPenaltyToBePaid() {
	return penaltyToBePaid;
}
public void setPenaltyToBePaid(int penaltyToBePaid) {
	this.penaltyToBePaid = penaltyToBePaid;
}
public int getExamFeeToPaid() {
	return examFeeToPaid;
}
public void setExamFeeToPaid(int examFeeToPaid) {
	this.examFeeToPaid = examFeeToPaid;
}
public int getTotalExamFeeToPaid() {
	return totalExamFeeToPaid;
}
public void setTotalExamFeeToPaid(int totalExamFeeToPaid) {
	this.totalExamFeeToPaid = totalExamFeeToPaid;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + examFeeToPaid;
	result = prime * result + penaltyToBePaid;
	result = prime * result + totalExamFeeToPaid;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	ExamFeeDetails other = (ExamFeeDetails) obj;
	if (examFeeToPaid != other.examFeeToPaid)
		return false;
	if (penaltyToBePaid != other.penaltyToBePaid)
		return false;
	if (totalExamFeeToPaid != other.totalExamFeeToPaid)
		return false;
	return true;
}
}
