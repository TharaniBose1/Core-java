package com.cg.attendencesystem.client;
		import com.cg.attendencesystem.beans.CourseDetails;
		import com.cg.attendencesystem.beans.ExamFeeDetails;
		import com.cg.attendencesystem.beans.LectureDetails;
		import com.cg.attendencesystem.beans.Student;
		import com.cg.attendencesystem.exceptions.StudentDetailsNotFoundException;
		import com.cg.attendencesystem.services.AttendenceServices;
		import com.cg.attendencesystem.services.AttendenceServicesImpl;
		public class MainClass {
			public static void main(String[] args) throws StudentDetailsNotFoundException {
				AttendenceServices attendenceServices=new AttendenceServicesImpl();
				int studentId1=attendenceServices.acceptStudentDetails("Tharani", "Bose", new CourseDetails(10021, 4, "ComputerScience and Engineering"), new ExamFeeDetails(2000), new LectureDetails(10,9));
				int studentId2=attendenceServices.acceptStudentDetails("Rakesh", "P", new CourseDetails(10021, 4, " Engineering"), new ExamFeeDetails(1000), new LectureDetails(10, 2));
				System.out.println("Generated ID"+studentId1);
				System.out.println("Generated ID"+studentId2);
				try {
					Student student1=attendenceServices.getStudentDetails(studentId1);
					System.out.println("Found Id is"+student1.getStudentId());
					int  calculatePenality1=attendenceServices.calculatePenality(studentId1);
					System.out.println("Calculated total exam fee to be paid is:=="+calculatePenality1);
				} catch (StudentDetailsNotFoundException e) {
					e.printStackTrace();
				}
				
				Student studentDetails=attendenceServices.getStudentDetails(1021);
				System.out.println("Students Details"+studentDetails.getFirstName());
			   java.util.List<Student> studentAllDetails= attendenceServices.getAllStudentDetails();
			    for (Student student : studentAllDetails) {
					System.out.println("All Students FirstName"+student.getFirstName()+"And their corresponding Last Name"+student.getLastName());
				}
			   
			}

		


	}


