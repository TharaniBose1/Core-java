package com.cg.attendencesystem.daoservices;
import java.util.List;
import com.cg.attendencesystem.beans.Student;
import com.cg.attendencesystem.util.AttendenceSystemUtil;
public class StudentDAOImpl implements StudentDAO {
private AttendenceSystemUtil attendenceUtil=new AttendenceSystemUtil();
	@Override
	public Student save(Student student) {
		student.setStudentId(AttendenceSystemUtil.getStudent_IDCounter());
		AttendenceSystemUtil.associateOfMap.put(student.getStudentId(), student);
		return student;
	}

	@Override
	public boolean update(Student student) {
		AttendenceSystemUtil.associateOfMap.put(student.getStudentId(), student);
		return true;
	}

	@Override
	public Student findId(int studentId) {
				return AttendenceSystemUtil.associateOfMap.get(studentId);
	}

	@Override
	public List<Student> findAllId() {
		return (List<Student>) AttendenceSystemUtil.associateOfMap.values();
	}
	

}
//if(student.getLectureDetails().getAttendencePercentage()<60 && student.getLectureDetails().getAttendencePercentage()>=50)