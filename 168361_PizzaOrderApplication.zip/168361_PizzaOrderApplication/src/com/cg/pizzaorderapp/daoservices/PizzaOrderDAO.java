package com.cg.pizzaorderapp.daoservices;
import com.cg.pizzaorderapp.beans.Customer;
import com.cg.pizzaorderapp.beans.PizzaOrder;
import com.cg.pizzaorderapp.util.PizzaOrderApplicationUtil;
public class PizzaOrderDAO implements IPizzaOrderDAO {
	@Override
	public PizzaOrder save(PizzaOrder pizzaOrder,Customer customer) {
		pizzaOrder.setOrderId(PizzaOrderApplicationUtil.getPICKEDORDERID());
		PizzaOrderApplicationUtil.pizzaEntry.put(pizzaOrder.getOrderId(), pizzaOrder);
		customer.setCustomerId(PizzaOrderApplicationUtil.PICKEDCUSTOMERID);
		PizzaOrderApplicationUtil.customerEntry.put(customer.getCustomerId(),customer );
		return pizzaOrder;
	}
	@Override
	public PizzaOrder findOne(int orderId) {
		return PizzaOrderApplicationUtil.pizzaEntry.get(orderId); 
	}
	@Override
	public boolean update(PizzaOrder pizzaOrder) {
		PizzaOrderApplicationUtil.pizzaEntry.put(pizzaOrder.getOrderId(), pizzaOrder);
		return true;}
}
