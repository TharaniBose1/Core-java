package com.cg.pizzaorderapp.util;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.cg.pizzaorderapp.beans.Customer;
import com.cg.pizzaorderapp.beans.PizzaOrder;
public class PizzaOrderApplicationUtil {
	public static Map<Integer, PizzaOrder> pizzaEntry=new HashMap<>();
	public static Map<Integer, Customer> customerEntry=new HashMap<>();
	public static int PICKEDORDERID = new Random().nextInt(400) + 1;
	public static int getPICKEDORDERID() {
		return PICKEDORDERID;}
	public static int PICKEDCUSTOMERID = new Random().nextInt(1000) + 1;
	public static int getPICKEDCUSTOMERID() {
		return PICKEDCUSTOMERID;}
}
