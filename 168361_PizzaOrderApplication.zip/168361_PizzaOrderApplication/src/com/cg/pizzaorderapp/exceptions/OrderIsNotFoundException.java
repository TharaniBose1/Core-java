package com.cg.pizzaorderapp.exceptions;
public class OrderIsNotFoundException extends Exception {
	public OrderIsNotFoundException() {
		super();}
	public OrderIsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);}
	public OrderIsNotFoundException(String message, Throwable cause) {
		super(message, cause);}
	public OrderIsNotFoundException(String message) {
		super(message);}
	public OrderIsNotFoundException(Throwable cause) {
		super(cause);}
}
