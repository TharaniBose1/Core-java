package com.cg.pizzaorderapp.exceptions;
public class InvalidEnteredToppings extends Exception {
	public InvalidEnteredToppings() {
		super();	
	}

	public InvalidEnteredToppings(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);	
	}

	public InvalidEnteredToppings(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidEnteredToppings(String message) {
		super(message);	
	}
	public InvalidEnteredToppings(Throwable cause) {
		super(cause);	
	}

}
