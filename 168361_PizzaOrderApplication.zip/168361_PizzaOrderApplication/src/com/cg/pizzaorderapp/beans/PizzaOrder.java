package com.cg.pizzaorderapp.beans;
public class PizzaOrder {
private int orderId;
private String preferredPizzaToppings;
private int customerId;
private double totalPrice;
public PizzaOrder(String preferredPizzaToppings) {
	super();
	this.preferredPizzaToppings = preferredPizzaToppings;
}
public PizzaOrder() {}
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public double getTotalPrice() {
	return totalPrice;
}
public void setTotalPrice(double totalPrice) {
	this.totalPrice = totalPrice;
}
public String getPreferredPizzaToppings() {
	return preferredPizzaToppings;
}
public void setPreferredPizzaToppings(String preferredPizzaToppings) {
	this.preferredPizzaToppings = preferredPizzaToppings;
}
}
