package com.cg.pizzaorderapp.services;
import com.cg.pizzaorderapp.beans.Customer;
import com.cg.pizzaorderapp.beans.PizzaOrder;
import com.cg.pizzaorderapp.exceptions.InvalidEnteredToppings;
import com.cg.pizzaorderapp.exceptions.InvalidPhoneNumberException;
import com.cg.pizzaorderapp.exceptions.OrderNotFoundException;
public interface IPizzaOrderService {
public int placeOrder(Customer customer,PizzaOrder pizza) throws InvalidEnteredToppings, InvalidPhoneNumberException;
public PizzaOrder getOrderDetails(int orderId) throws OrderNotFoundException;
double calculateTotalPrice(int OrderId) throws OrderNotFoundException;
}
