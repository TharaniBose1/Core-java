import java.util.ArrayList;
import java.util.stream.Stream;

import com.cg.collectiondemo.beans.Associate;

public class MaimClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Associate> associates=new ArrayList<>();
		//insert
		associates.add(new Associate(117, "Tharani", "Bose"));
		associates.add(new Associate(114, "rani", "Bose"));
		associates.add(new Associate(116, "harani", "Bose"));
		associates.add(new Associate(115, "arani", "Bose"));
		
		Stream<Associate> st1=associates.stream();
		Stream<Associate> st2=st1.distinct();
		Stream<Associate>st3=st2.filter(associate->associate.getFirstName().startsWith("T"));
		System.out.println(st3.count());
		st3.forEach(associate->System.out.println(associate));
	}

}
