package com.cg.collectiondemo.classes;
import com.cg.collectiondemo.beans.Associate;
public interface Condition {
	public boolean startWithCall(Associate associate);
	
}
