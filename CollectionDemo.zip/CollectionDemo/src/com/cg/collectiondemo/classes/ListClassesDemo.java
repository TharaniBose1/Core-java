
package com.cg.collectiondemo.classes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

import com.cg.collectiondemo.beans.Associate;
public class ListClassesDemo {
	public static  void listOfClassess(){
		/*
		ArrayList<Associate> associates=new ArrayList<>();
		//insert
		associates.add(new Associate(117, "Tharani", "Bose"));
		associates.add(new Associate(114, "rani", "Bose"));
		associates.add(new Associate(116, "harani", "Bose"));
		associates.add(new Associate(115, "arani", "Bose"));
		System.out.println("Records got inserted");
		associates.add(new Associate(200, "Karthiyayini", "Perumal Thevar"));
		//search
		Associate associateToSearch=new Associate(117, "Tharani", "Bose");
		int idx=associates.indexOf(associateToSearch);
		System.out.println("Inserted index"+idx);
		//remove
		associates.remove(idx);
		System.out.println("Element got removed at the index"+idx);
		//sort
Collections.sort(associates, new AssociateComparator());
System.out.println("Elements got sorted"+associates);
Collections.sort(associates);
System.out.println("Elements got sorted"+associates);
		 */
		LinkedList<Associate> associates=new LinkedList<>();
		//insert
		associates.add(new Associate(117, "Aharani", "Bose"));
		associates.add(new Associate(114, "Vani", "Bose"));
		associates.add(new Associate(116, "Zarani", "Bose"));
		associates.add(new Associate(115, "Drani", "Bose"));
//		System.out.println("Records got inserted");
//		associates.add(new Associate(200, "Karthiyayini", "Perumal Thevar"));
//		//search
//		Associate associateToSearch=new Associate(116, "Zarani", "Bose");
//		int idx=associates.indexOf(associateToSearch);
//		System.out.println("Inserted index"+idx);
//		//remove
//		associates.remove(idx);
//		System.out.println("Element got removed at the index"+idx);
//		//sort
		//Collections.sort(associates, new AssociateComparator());

		/*Comparator<Associate> assCompator=(e1,e2)->e1.getAssociateId()-e2.getAssociateId();
Collections.sort(associates,assCompator );*/
		/*Collections.sort(associates,(e1,e2)->e1.getAssociateId()-e2.getAssociateId() );
		associates.forEach((e)->System.out.println("HEY THIS FOR EACH METHOD   :  "+e.getFirstName())); 
		System.out.println("Elements got sorted"+associates);
		Collections.sort(associates);
		System.out.println("Elements got sorted"+associates);*/
		//printAssociateDetails1(associates, (associate)->associate.getFirstName().startsWith("A"));
		//printAssociateDetails2(associates, (associate)->associate.getFirstName().startsWith("A"),(e)->System.out.println("Found assosiate 2"+e.getFirstName()));
		Stream<Associate> st1=associates.stream();
		Stream<Associate> st2=st1.distinct();
		Stream<Associate>st3=st2.filter(associate->associate.getFirstName().startsWith("A"));
	//	System.out.println(st3.count());
		st3.forEach(associate->System.out.println(associate));
	}
	/*@FunctionalInterface
	public interface Condition {
		public boolean startWithCall(Associate associate);	
	}
	private static void printAssociateDetails1(List<Associate>asslist,Condition condition) {
		for (Associate associate : asslist) {
			if(condition.startWithCall(associate))
				//ass.accept(associate);
				System.out.println("ELEMENTS ARE from 1"+associate);
		}
	}
	private static void printAssociateDetails2(List<Associate>asslist,Condition condition,Consumer<Associate> ass) {
		for (Associate associate : asslist) {
			if(condition.startWithCall(associate))
				ass.accept(associate);
				//System.out.println("ELEMENTS ARE "+associate);
		}
	}*/

}
