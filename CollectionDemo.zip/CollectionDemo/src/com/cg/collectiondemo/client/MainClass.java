package com.cg.collectiondemo.client;
import com.cg.collectiondemo.classes.ListClassesDemo;
public class MainClass {
	public static void main(String[] args) {
ListClassesDemo.listOfClassess();		
	}
}
