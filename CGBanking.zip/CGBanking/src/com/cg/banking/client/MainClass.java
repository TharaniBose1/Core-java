package com.cg.banking.client;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
public class MainClass {
	public static void main(String[] args) {
		Transaction[] transactionsob1= new Transaction[] {
				new Transaction(001,45000, "rtgs", "Online","Success"),
				new Transaction(002, 35000, "IMPS", "Online", "Failure")	
		};
		Transaction[] transactionsob2= new Transaction[] {
				new Transaction(001,45000, "rtgs", "Online","Success"),
				new Transaction(002, 35000, "IMPS", "Online", "Failure")     
		};
		Transaction[] transactionsob3= new Transaction[] {
				new Transaction(001,45000, "rtgs", "Online","Success"),
				new Transaction(002, 35000, "IMPS", "Online", "Failure"),
				new Transaction(003, 78000, "UPI", "Offline", "Success")
		};
		Transaction[] transactionsob4= new Transaction[] {
				new Transaction(001,45000, "rtgs", "Online","Success"),
				new Transaction(002, 35000, "IMPS", "Online", "Failure"),
				new Transaction(003, 78000, "UPI", "Offline", "Success")
		};
		Transaction[] transactionsob5= new Transaction[] {
				new Transaction(001,45000, "rtgs", "Online","Success"),
				new Transaction(002, 35000, "IMPS", "Online", "Failure"),
				new Transaction(003, 78000, "UPI", "Offline", "Success")
		};
		Account[] account= new Account[] {
				new Account(78945, transactionsob1),
				new Account(456123, transactionsob2),
				new Account(789124, transactionsob3),
				new Account(256446, transactionsob4),
				new Account(2480144, transactionsob5)};
		Customer customer=new Customer(111, 9835, "Tharani", "Bose", "GGJHBS5644B", account);
		for (Account account2 : account) {
			System.out.println(account2.getAccountNo());
		}		
	};

}

