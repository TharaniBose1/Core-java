package com.cg.banking.beans;
public class Transaction {
	private int transactionId,timeStamp,amount;
	private String transactionType,transactionLocation,modeOfTranscation,transactionStatus;
	public Transaction(int transactionId, int amount, String transactionType, String modeOfTranscation,
			String transactionStatus) {
		super();
		this.transactionId = transactionId;
		this.amount = amount;
		this.transactionType = transactionType;
		this.modeOfTranscation = modeOfTranscation;
		this.transactionStatus = transactionStatus;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(int timeStamp) {
		this.timeStamp = timeStamp;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionLocation() {
		return transactionLocation;
	}
	public void setTransactionLocation(String transactionLocation) {
		this.transactionLocation = transactionLocation;
	}
	public String getModeOfTranscation() {
		return modeOfTranscation;
	}
	public void setModeOfTranscation(String modeOfTranscation) {
		this.modeOfTranscation = modeOfTranscation;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	
	

}
