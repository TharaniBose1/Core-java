package com.cg.classess;
public class MainClassHaToFile {
	public static void main(String[] args) {
		HashToFileVV  ob=new HashToFileVV();
		ob.hashToFileSerial();
		ob.FileToHashDeserial();    
	}
}