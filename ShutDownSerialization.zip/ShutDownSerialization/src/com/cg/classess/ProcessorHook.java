package com.cg.classess;
import com.cg.client.MainClass;
public class ProcessorHook extends Thread{
		@Override
		public void run(){
			System.out.println("Status="+ MainClass.status);
			System.out.println("FileName="+ MainClass.fileName);
			if(! MainClass.status.equals("FINISHED")){
				System.out.println("Seems some error, sending alert");
			}
			
		}
	}

