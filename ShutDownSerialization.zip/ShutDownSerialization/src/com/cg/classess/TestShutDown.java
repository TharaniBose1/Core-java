package com.cg.classess;

class MyThread extends Thread{  
    public void run(){  
    	int a []=new int[10];
    	
    	for(int i=0;i<10;i++) {
    		a[i]=i;
  System.out.println(a[i]);
    	}
        System.out.println("shut down hook task completed..");  
    }  
}  
  
public class TestShutDown{  
public static void main(String[] args)throws Exception {  
  
Runtime r=Runtime.getRuntime();  
r.addShutdownHook(new MyThread());  
 System.out.println("Have registered");
 System.exit(0);
System.out.println("Now main sleeping... press ctrl+c to exit");  
try{Thread.sleep(500);}catch (Exception e) {}  
}  
}  