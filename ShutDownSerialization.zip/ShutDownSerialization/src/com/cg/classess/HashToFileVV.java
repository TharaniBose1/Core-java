package com.cg.classess;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
public class HashToFileVV extends ProcessorHook{
public  void hashToFileSerial() {
	HashMap<Integer, String> hashmap = new HashMap<Integer, String>();
    hashmap.put(1, "JAVA");
    hashmap.put(2, "JAVASCRIPT");
    hashmap.put(3, "DATASCIENCE");
    hashmap.put(4, "BIG DATA");
    hashmap.put(5, "CLOUD");
    try
           {
                  FileOutputStream fos =
                     new FileOutputStream("D:\\hashmap.txt");
                  ObjectOutputStream oos = new ObjectOutputStream(fos);
                  oos.writeObject(hashmap);
                  oos.close();
                  fos.close();
                  System.out.printf("Serialized HashMap data is saved in hashmap.txt");
           }catch(IOException ioe)
            {
                  ioe.printStackTrace();
            }
  }
public   void FileToHashDeserial() {
	 	    HashMap<Integer, String> map = null;
	      try
	      {
	         ObjectInputStream ois = new ObjectInputStream(new FileInputStream("D:\\hashmap.txt"));
	         map = (HashMap) ois.readObject();
	         ois.close();
	         System.out.println("Deserialized HashMap"+map);
	   	  
	      }catch(IOException  |ClassNotFoundException ioe)
	      {
	         ioe.printStackTrace();
	         return;
	      }
	      }
}

