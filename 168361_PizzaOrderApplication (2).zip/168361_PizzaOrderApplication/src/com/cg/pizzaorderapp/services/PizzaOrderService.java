package com.cg.pizzaorderapp.services;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.pizzaorderapp.beans.Customer;
import com.cg.pizzaorderapp.beans.PizzaOrder;
import com.cg.pizzaorderapp.daoservices.IPizzaOrderDAO;
import com.cg.pizzaorderapp.daoservices.PizzaOrderDAO;
import com.cg.pizzaorderapp.exceptions.InvalidEnteredToppings;
import com.cg.pizzaorderapp.exceptions.InvalidPhoneNumberException;
import com.cg.pizzaorderapp.exceptions.OrderNotFoundException;
public class PizzaOrderService implements IPizzaOrderService {
	private IPizzaOrderDAO ipizzaOrderDAO=new PizzaOrderDAO();
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)throws InvalidEnteredToppings, InvalidPhoneNumberException {
		PizzaOrder pizzaOrder;
		Pattern pattern = Pattern.compile("^[0-9]{10}$");//to validate phone number
		Matcher matcher = pattern.matcher(customer.getPhone()); 
		 if (!matcher.matches()) throw new InvalidPhoneNumberException("Enter Valid Number");
		if(!(pizza.getPreferredPizzaToppings().equals("Capsicum")||pizza.getPreferredPizzaToppings().equals("Mushroom")||pizza.getPreferredPizzaToppings().equals("Jalapeno")||pizza.getPreferredPizzaToppings().equals("Paneer"))) 
		throw new InvalidEnteredToppings("Please enter one Topping or Enter Valid Toppings");
		//if (!Pattern.compile(customer.getPhone()).matcher(customer.getPhone()).find()) throw new InvalidPhoneNumberException("Please Enter validate Phone Number");
		pizzaOrder=ipizzaOrderDAO.save(pizza,customer);
		return pizzaOrder.getOrderId();
	}
	@Override
	public PizzaOrder getOrderDetails(int orderId) throws OrderNotFoundException {
		PizzaOrder pizzaOrder=ipizzaOrderDAO.findOne(orderId);
		if(pizzaOrder==null)throw new OrderNotFoundException("Order Details Not Found Exception");
		return pizzaOrder;}
	@Override
	public double calculateTotalPrice(int OrderId) throws OrderNotFoundException {
		PizzaOrder pizzaOrder =(PizzaOrder) this.getOrderDetails(OrderId);
		if(pizzaOrder.getPreferredPizzaToppings().equals("Capsicum")) {
			pizzaOrder.setTotalPrice(350+30);
			ipizzaOrderDAO.update(pizzaOrder);
		return pizzaOrder.getTotalPrice();}
		else if(pizzaOrder.getPreferredPizzaToppings().equals("Mushroom")) {
			pizzaOrder.setTotalPrice(350+50);
			ipizzaOrderDAO.update(pizzaOrder);
		return pizzaOrder.getTotalPrice();}
		else if(pizzaOrder.getPreferredPizzaToppings().equals("Jalapeno")) {
			pizzaOrder.setTotalPrice(350+70);
			ipizzaOrderDAO.update(pizzaOrder);
		return pizzaOrder.getTotalPrice();}
		else {
			pizzaOrder.setTotalPrice(350+85);
			ipizzaOrderDAO.update(pizzaOrder);
		return pizzaOrder.getTotalPrice();}
	}
	
}
