package com.cg.pizzaorderapp.exceptions;
public class OrderNotFoundException extends Exception {
	public OrderNotFoundException() {
		super();	}
	public OrderNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);	}
	public OrderNotFoundException(String message, Throwable cause) {
		super(message, cause);}
	public OrderNotFoundException(String message) {
		super(message);}
	public OrderNotFoundException(Throwable cause) {
		super(cause);}
}
