package com.cg.pizzaorderapp.client;
import java.util.Scanner;

import com.cg.pizzaorderapp.beans.Customer;
import com.cg.pizzaorderapp.beans.PizzaOrder;
import com.cg.pizzaorderapp.exceptions.InvalidEnteredToppings;
import com.cg.pizzaorderapp.exceptions.InvalidPhoneNumberException;
import com.cg.pizzaorderapp.exceptions.OrderNotFoundException;
import com.cg.pizzaorderapp.services.IPizzaOrderService;
import com.cg.pizzaorderapp.services.PizzaOrderService;
public class Client {
	public static void main(String[] args) {
		IPizzaOrderService ipPizzaOrderService=new PizzaOrderService();
		Scanner scan=new Scanner(System.in);
		while(true) {
		System.out.println("Enter your choice\n");
		System.out.println("1.Place Order\n");
		System.out.println("2.Get Price\n");
		System.out.println("3.exit");
		int choice=scan.nextInt();
		switch(choice) {
		case 1:{
			System.out.println("Enter the name of the Customer:");
			String custName=scan.next();
			System.out.println("Enter customer address:");
			String address=scan.next();
			System.out.println("Enter  Customer Phone number:");
			String phone=scan.next();
			System.out.println("Type of Pizza Topping preferred:");
			String preferredPizzaToppings=scan.next();
			try {
				int OrderId=ipPizzaOrderService.placeOrder(new Customer(custName, address, phone),new PizzaOrder(preferredPizzaToppings));
				System.out.println("Genrated Order ID"+OrderId);
			} catch (InvalidEnteredToppings |InvalidPhoneNumberException  e){
				e.printStackTrace();}	
		break;}
		case 2:{
			System.out.print("Enter the Order Id:");
			int orderId=scan.nextInt();
			try {
				System.out.println("Price is"+ipPizzaOrderService.calculateTotalPrice(orderId));
				//ipPizzaOrderService.getOrderDetails(orderId);
			} catch (OrderNotFoundException e) {
				e.printStackTrace();}
		break;}
		default:System.out.println("Thanks for Using the service");
		}}}}

