package com.cg.pizzaorderapp.test;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.pizzaorderapp.beans.Customer;
import com.cg.pizzaorderapp.beans.PizzaOrder;
import com.cg.pizzaorderapp.exceptions.InvalidEnteredToppings;
import com.cg.pizzaorderapp.exceptions.InvalidPhoneNumberException;
import com.cg.pizzaorderapp.exceptions.OrderNotFoundException;
import com.cg.pizzaorderapp.services.IPizzaOrderService;
import com.cg.pizzaorderapp.services.PizzaOrderService;
import com.cg.pizzaorderapp.util.PizzaOrderApplicationUtil;
public class PizzaOrderApplicationTest {
public static 	IPizzaOrderService pizzaServices;
@BeforeClass
public static void setUpEnv() {
	pizzaServices=new PizzaOrderService();
}
@Before
public void setUpData() throws InvalidEnteredToppings, InvalidPhoneNumberException {
	Customer customer1=new Customer("Tharani","Madurai","9843705945");
	PizzaOrder Pizza1=new PizzaOrder("Mushrrom");
	Customer customer2=new Customer("tHAA", "Theni	", "3752745650");
	PizzaOrder Pizza2=new PizzaOrder("Mushrrom");
	PizzaOrderApplicationUtil.PICKEDORDERID=3;
	PizzaOrderApplicationUtil.PICKEDCUSTOMERID=403;
}
@Test(expected=OrderNotFoundException.class)
public void testForInvalidGetDetails() throws OrderNotFoundException {
pizzaServices.getOrderDetails(421);	
}
@After
public void tearUpData() {
	PizzaOrderApplicationUtil.customerEntry.clear();
	PizzaOrderApplicationUtil.pizzaEntry.clear();
	PizzaOrderApplicationUtil.PICKEDORDERID=1;
	PizzaOrderApplicationUtil.PICKEDCUSTOMERID=400;
	
}
@AfterClass
public void tearUpEnv() {
	pizzaServices=null;
	
}


}
