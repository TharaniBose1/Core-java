package com.cg.pizzaorderapp.daoservices;
import com.cg.pizzaorderapp.beans.Customer;
import com.cg.pizzaorderapp.beans.PizzaOrder;
public interface IPizzaOrderDAO {
public PizzaOrder save(PizzaOrder pizzaOrder,Customer customer);
public boolean update(PizzaOrder pizzaOrder);
public PizzaOrder findOne(int orderId);

}
