package com.cg.banking.dao;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingApplicationUtil;
public class TransactionDAOImpl implements TransactionDAO {
	@Override
	public Transaction save(Transaction transaction) {
		transaction.setTransactionId(BankingApplicationUtil.getTRANSACTIONID());
		BankingApplicationUtil.transcationEntry.put(transaction.getTransactionId(),transaction);
		return transaction;
	}
	@Override
	public boolean update(Transaction transaction) {
		BankingApplicationUtil.transcationEntry.put(transaction.getTransactionId(),transaction);
		return true;
	}

	@Override
	public Transaction findOne(long accountNumber) {
		return BankingApplicationUtil.transcationEntry.get(accountNumber);}
	@Override
	public List<Transaction> findAll() {
		return new ArrayList<Transaction>(BankingApplicationUtil.transcationEntry.values());
	}

}
