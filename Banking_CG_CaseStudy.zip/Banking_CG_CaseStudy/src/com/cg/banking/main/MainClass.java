package com.cg.banking.main;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.itextpdf.text.log.SysoCounter;
public class MainClass {
	public static void main(String[] args) throws InvalidAmountException {
		BankingServices bankingServices=new BankingServicesImpl();
		while(true)
		{ Scanner scan=new Scanner(System.in);
		System.out.println("1. Open a Account ");
		System.out.println("2. Deposit");
		System.out.println("3.Withdraw");
		System.out.println("4. GetAccountDetails");
		System.out.println("5. GetTranscationDetails");
		System.out.println("6. Fund Transfer");
		System.out.println("7.Mini statement in recepit");
		System.out.println("8.Exit");
		System.out.println("Enter your choice :  ");
		try {
			switch(scan.nextInt())
			{
			case 1:{
				System.out.println("AccountType and initial Balance");
				Account account;
				account = bankingServices.openAccount(scan.next(), scan.nextFloat());
				System.out.println("Account No "+account.getAccountNo()+"Pin Number"+account.getPinNumber());
				break;  }
			case 2:{
				System.out.println("Enter AccountNo and amount to be deposited");

				System.out.println("Current Balance is"+bankingServices.depositAmount(scan.nextLong(), scan.nextFloat()));
				break;} 
			
			case 3:{
				System.out.println("Enter AccountNumber,Amount and Pin number     :  ");

				System.out.println("Current Balance is"+bankingServices.withdrawAmount(scan.nextLong(), scan.nextFloat(), scan.nextInt()));
				break;	} 
			
			case 4:{
				System.out.println("Enter AccountNumber");
				Account account;

				account = bankingServices.getAccountDetails(scan.nextLong());
				System.out.println("Account No   :"+account.getAccountNo()+"Account Status   :"+account.getStatus()+"Account Type  :"+account.getAccountType());	

				//+"Transactions"+account.getTransactions()
				break;}
			case 5:{
				System.out.println("Enter the Account Number");
				List<Transaction> listOfTransactions=bankingServices.getAccountAllTransaction(scan.nextLong());
				/*for (int i = 0; i < listOfTransactions.size(); i++) {
					System.out.println(listOfTransactions.get(i).getTransactionId());
					System.out.println(listOfTransactions.get(i).getTransactionType());
					System.out.println(listOfTransactions.get(i).getAmount());		
				} */
				System.out.println(listOfTransactions);
				break;
			}
			case 6:{
				System.out.println("Enter the Account NumberTo,AccountFrom,TransferAmount,pinNumber ");
				if(bankingServices.fundTransfer(scan.nextLong(), scan.nextLong(), scan.nextFloat(),scan.nextInt()))
					System.out.println("Fund got tranferred!");

				break;}
			case 7:{System.out.println("Enter account Number");
			bankingServices.pdfGenerator(scan.nextLong());
			break;
			}
			case 8:{
				System.out.println("Exit");
				System.exit(0);}

			}}
		catch (InvalidAccountTypeException | InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException | IOException | com.itextpdf.text.DocumentException e) {
			e.printStackTrace();
			//>>>>>>>>>>>
		}}}}





/*try {
			Account account1=bankingServices.openAccount("Savings Account", 6000);
			System.out.println("Generated AccountNumber  :"+account1.getAccountNo());
			System.out.println("Generated pinNumber :"+account1.getPinNumber());
			Account account2=bankingServices.openAccount("Savings Account", 5000);
			System.out.println("Generated AccountNumber  :"+account2.getAccountNo());
			System.out.println("Generated pinNumber :"+account2.getPinNumber());
			float amount=bankingServices.depositAmount(1001, 2000);
			System.out.println("has deposited and current balance is   :"+amount);
			float amount1= bankingServices.withdrawAmount(1001, 1000, account1.getPinNumber());
			System.out.println("Withdrawed and current balance is    :"+amount1);
			String str1=bankingServices.accountStatus(1001);
			System.out.println("Account status be"+str1);
			//	String str2=bankingServices.accountStatus(1010);
			//System.out.println("Account status be"+str2);
			Account account3=bankingServices.getAccountDetails(1001);
			System.out.println("Account Holder's Account Type    :"+account3.getAccountType());
			if(bankingServices.fundTransfer(1002, 1001, 200, account1.getPinNumber())) {
				System.out.println("Updated after performing fund TransferFrom  :"+bankingServices.getAccountDetails(1001).getAccountBalance());
				System.out.println("Updated after performing fund Transfer    :"+bankingServices.getAccountDetails(1002).getAccountBalance());}
			List<Transaction> listOfTr1=bankingServices.getAccountAllTransaction(1001);
			System.out.println("Number of total transcations  :"+listOfTr1.size());
			List<Transaction> listOfTr2=bankingServices.getAccountAllTransaction(1002);
			System.out.println("Number of total transcations  :"+listOfTr2.size());
			List<Account>list =bankingServices.getAllAccountDetails();
			list.forEach(lists ->System.out.println("Details :"+lists.getAccountNo()+"  "+lists.getAccountBalance()));
		} catch (BankingServicesDownException | AccountNotFoundException | AccountBlockedException | InsufficientAmountException | InvalidPinNumberException | InvalidAccountTypeException e) {
			e.printStackTrace();
		}*/

