package com.cg.property.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
public class MainClass {
	public static void main(String[] args) {
		try {
			Properties properties=new Properties();
			properties.load(new FileInputStream(".\\resources\\project.properties"));
			String v1=properties.getProperty("key3");
			System.out.println(v1);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
