package com.cg.attendencesystem.util;
import java.util.HashMap;

import com.cg.attendencesystem.beans.Student;
public class AttendenceSystemUtil {
	public static int STUDENTIDCOUNTER=1020;
		//	private static int ARRAYINDEXCOUNTER=0;
	//public static Student [] students=new Student[10];	
	public static HashMap<Integer, Student> students=new HashMap<>(); 
	public static int getSTUDENTIDCOUNTER() {
		return ++STUDENTIDCOUNTER;
	}
	/*
	public static int getARRAYINDEXCOUNTER() {
		return ARRAYINDEXCOUNTER++;
	}
	*/
}
