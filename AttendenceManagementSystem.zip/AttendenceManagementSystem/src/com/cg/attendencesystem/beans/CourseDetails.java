package com.cg.attendencesystem.beans;
public class CourseDetails {
private int courseId,courseDuration;
private String courseName;
public CourseDetails() {}
public CourseDetails(int courseId, int courseDuration, String courseName) {
	super();
	this.courseId = courseId;
	this.courseDuration = courseDuration;
	this.courseName = courseName;
}
public int getCourseId() {
	return courseId;
}
public void setCourseId(int courseId) {
	this.courseId = courseId;
}
public int getCourseDuration() {
	return courseDuration;
}
public void setCourseDuration(int courseDuration) {
	this.courseDuration = courseDuration;
}
public String getCourseName() {
	return courseName;
}
public void setCourseName(String courseName) {
	this.courseName = courseName;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + courseDuration;
	result = prime * result + courseId;
	result = prime * result + ((courseName == null) ? 0 : courseName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	CourseDetails other = (CourseDetails) obj;
	if (courseDuration != other.courseDuration)
		return false;
	if (courseId != other.courseId)
		return false;
	if (courseName == null) {
		if (other.courseName != null)
			return false;
	} else if (!courseName.equals(other.courseName))
		return false;
	return true;
}

}
