package com.cg.attendencesystem.test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.attendencesystem.beans.CourseDetails;
import com.cg.attendencesystem.beans.ExamFeeDetails;
import com.cg.attendencesystem.beans.LectureDetails;
import com.cg.attendencesystem.beans.Student;
import com.cg.attendencesystem.exceptions.StudentDetailsNotFoundException;
import com.cg.attendencesystem.services.AttendenceServices;
import com.cg.attendencesystem.services.AttendenceServicesImpl;
import com.cg.attendencesystem.util.AttendenceSystemUtil;
public class AttendenceServicesTest {
public static AttendenceServices attendenceServices;
@BeforeClass
public static void setUpTestEnv() {
	attendenceServices=new AttendenceServicesImpl();
}
@Before
public void setUpTestData() {
	Student studentob1=new Student(1021,"Tharani", "Bose", new CourseDetails(10021, 4, "ComputerScience and Engineering"), new ExamFeeDetails(2000), new LectureDetails(10, 10));
    Student studentob2=new Student(1022,"Rakesh", "P", new CourseDetails(10021, 4, " Engineering"), new ExamFeeDetails(2000), new LectureDetails(10, 2));
    AttendenceSystemUtil.students.put(studentob1.getStudentId(), studentob1);
    AttendenceSystemUtil.students.put(studentob2.getStudentId(), studentob2);
    AttendenceSystemUtil.STUDENTIDCOUNTER=1022;
}
@Test
public void testAcceptStudentDetailsForValidData() {
	int expectedStudentId=1023;
	int actualStudentId=attendenceServices.acceptStudentDetails("Karthiyayini", "Perumal", new CourseDetails(10022, 4, "Statics"), new ExamFeeDetails(1500), new LectureDetails(20, 18));
	Assert.assertEquals(expectedStudentId, actualStudentId);		
}
@Test(expected=StudentDetailsNotFoundException.class)
public void testGetStudentDetailForInvalidData() throws StudentDetailsNotFoundException{
	Student student=attendenceServices.getStudentDetails(1025);
}
@Test
public void testGetStudentDetailForValidData() throws StudentDetailsNotFoundException{
	Student expectedStudentDetails=new Student(1021,"Tharani", "Bose", new CourseDetails(10021, 4, "ComputerScience and Engineering"), new ExamFeeDetails(2000), new LectureDetails(10, 8));
	Student actualStudentDetails=attendenceServices.getStudentDetails(1021);
	Assert.assertEquals(expectedStudentDetails, actualStudentDetails);
}
@	Test
public void testCalculatePenalityForValidData()throws StudentDetailsNotFoundException{
	int expectedCalculatedPenality=2400;
	int actualCalculatedPenality=attendenceServices.calculatePenality(1021);
	Assert.assertEquals(expectedCalculatedPenality, actualCalculatedPenality);
}
@Test(expected=StudentDetailsNotFoundException.class)
public void testCalculatePenalityForInvalidData() throws StudentDetailsNotFoundException{
	int actualCalculatedPenality=attendenceServices.calculatePenality(1212);
}
@Test
public void testGetAllStudentDetailsForValidData() {
ArrayList<Student> expectedStudentsAllDetails=new ArrayList<>();
expectedStudentsAllDetails.add(new Student(1021,"Tharani", "Bose", new CourseDetails(10021, 4, "ComputerScience and Engineering"), new ExamFeeDetails(2000), new LectureDetails(10, 8)));
expectedStudentsAllDetails.add(new Student(1022,"Rakesh", "P", new CourseDetails(10021, 4, " Engineering"), new ExamFeeDetails(2000), new LectureDetails(10, 8)));
ArrayList<Student> actualStudentsAllDetails=(ArrayList<Student>) attendenceServices.getAllStudentDetails();
Assert.assertEquals(expectedStudentsAllDetails, actualStudentsAllDetails);
}
@After
public void tearUpTestData() {
	AttendenceSystemUtil.STUDENTIDCOUNTER=1020;
	AttendenceSystemUtil.students.clear();
}

@AfterClass
public static void  tearUpTestEnv() {
attendenceServices=null;

}
}

