package com.cg.attendencesystem.services;
import java.util.ArrayList;
import java.util.List;
import com.cg.attendencesystem.beans.CourseDetails;
import com.cg.attendencesystem.beans.ExamFeeDetails;
import com.cg.attendencesystem.beans.LectureDetails;
import com.cg.attendencesystem.beans.Student;
import com.cg.attendencesystem.daoservices.StudentDAO;
import com.cg.attendencesystem.daoservices.StudentDAOImpl;
import com.cg.attendencesystem.exceptions.StudentDetailsNotFoundException;
import com.cg.attendencesystem.util.AttendenceSystemUtil;
public class AttendenceServicesImpl implements AttendenceServices{
private StudentDAOImpl studentDAO=new StudentDAOImpl();
	@Override
	public int acceptStudentDetails(String firstName, String lastName, CourseDetails courseDetails,
		ExamFeeDetails examFeeDetails, LectureDetails lectureDetails) {
		Student student=new Student(firstName, lastName, courseDetails, examFeeDetails, lectureDetails);
		studentDAO.save(student);
		return student.getStudentId();
	}
	@Override
	public int calculatePenality(int studentId) throws StudentDetailsNotFoundException {
		Student student=(Student)this.getStudentDetails(studentId);
		studentDAO.update(student);
		//student.getLectureDetails().setNoOfLecturesAttended(student.getLectureDetails().getNoOfLecturesAttended());
		//student.getLectureDetails().setNoOfLecturesConducted(student.getLectureDetails().getNoOfLecturesConducted());
		student.getLectureDetails().setAttendencePercentage(student.getLectureDetails().getNoOfLecturesAttended()/student.getLectureDetails().getNoOfLecturesConducted()*100);
		if(student.getLectureDetails().getAttendencePercentage()>=75) {
			student.getExamFeeDetails().setPenaltyToBePaid(0);
			student.getExamFeeDetails().setTotalExamFeeToPaid(student.getExamFeeDetails().getExamFeeToPaid()+student.getExamFeeDetails().getPenaltyToBePaid());
		return student.getExamFeeDetails().getTotalExamFeeToPaid();
		}
		else if(student.getLectureDetails().getAttendencePercentage()<75&&student.getLectureDetails().getAttendencePercentage()>=60 )
		{
			student.getExamFeeDetails().setPenaltyToBePaid(student.getExamFeeDetails().getExamFeeToPaid()/10);
			student.getExamFeeDetails().setTotalExamFeeToPaid(student.getExamFeeDetails().getExamFeeToPaid()+student.getExamFeeDetails().getPenaltyToBePaid());
		   return student.getExamFeeDetails().getTotalExamFeeToPaid();
		}
		else  if(student.getLectureDetails().getAttendencePercentage()<60 && student.getLectureDetails().getAttendencePercentage()>=50){
			student.getExamFeeDetails().setPenaltyToBePaid(student.getExamFeeDetails().getExamFeeToPaid()/5);
			student.getExamFeeDetails().setTotalExamFeeToPaid(student.getExamFeeDetails().getExamFeeToPaid()+student.getExamFeeDetails().getPenaltyToBePaid());
			 return student.getExamFeeDetails().getTotalExamFeeToPaid();
		}
		else
		{
		student.getExamFeeDetails().setPenaltyToBePaid((student.getExamFeeDetails().getExamFeeToPaid()*3)/10);	
		student.getExamFeeDetails().setTotalExamFeeToPaid(student.getExamFeeDetails().getExamFeeToPaid()+student.getExamFeeDetails().getPenaltyToBePaid());
		return student.getExamFeeDetails().getTotalExamFeeToPaid();
		}
	//	else throw new StudentDetailsNotFoundException("Exam can't be attended due to Lack of attendence thus,course must be re-started");		    
		
	}
	@Override
	public Student getStudentDetails(int studentId) throws StudentDetailsNotFoundException {
		Student student=studentDAO.findId(studentId);
		if(student==null )throw new StudentDetailsNotFoundException("Associate ID is not Found!"+studentId);
		return student;
	}/*
	@Override
	public Student[] getAllStudentDetails() {
		return AttendenceSystemUtil.students;
	}	
	*/
	@Override
	public List<Student> getAllStudentDetails() {
		List<Student> studentAllDetails= studentDAO.findAllId();
		return studentAllDetails;
	}
	
	
}
