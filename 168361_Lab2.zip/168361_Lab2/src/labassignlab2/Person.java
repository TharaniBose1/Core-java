package labassignlab2;
public class Person {
	private String firstName,lastName,gender,phoneNumber;
	private  int age;
	private float weight;
	Gender genderEnum;
	public Person() {}
	public Person(String firstName, String lastName, String gender,int age,float weight) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
	}
	public Person(String firstName, String lastName, String gender, String phoneNumber, int age, float weight) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
		this.age = age;
		this.weight = weight;
	}
	public Person(String firstName, String lastName,String phoneNumber, int age, float weight,
			Gender genderEnum) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.age = age;
		this.weight = weight;
		this.genderEnum = genderEnum;
	}
	
	public Gender getGenderEnum() {
		return genderEnum;
	}
	public void setGenderEnum(Gender genderEnum) {
		this.genderEnum = genderEnum;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
}
