package labassignlab2;
import java.util.Scanner;
public class LabAss22 {
	public static void main(String[] args) {
		System.out.print("Enter the Number  to be Checked as postive or negative:");
		Scanner scan=new Scanner(System.in);
		int number=scan.nextInt();
		if(number<0)
			System.out.println("Inputed Number is Negative Number"+number);
		else
			System.out.println("Inputed Number is Postive Number"+number);
	}
}
