package labassignlab2;
import java.util.Scanner;
public class MethodsToGet {
	Scanner scan=new Scanner(System.in);
	String firstName=scan.next();
	String lastName=scan.next();
	String phoneNumber=scan.next();
	int age=scan.nextInt();
	float weight=scan.nextFloat();
	String gender=scan.next();
	Person person=new Person(firstName, lastName, phoneNumber, age, weight, Gender.valueOf(gender));//construtor to accept phone number
	public void DisplayDetails() //Method to display values which got through construtor
	{
		System.out.println("Display the inputted Details");
		System.out.println("FirstName :"+person.getFirstName());
		System.out.println("LastName :"+person.getLastName());
		System.out.println("Gender :"+Gender.valueOf(gender).getGenderName());
		System.out.println("Age :"+person.getAge());
		System.out.println("Weight :"+person.getWeight());
		System.out.println("Phone Number :"+person.getPhoneNumber());
	}

}
