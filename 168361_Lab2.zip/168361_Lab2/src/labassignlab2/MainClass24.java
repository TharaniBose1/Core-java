package labassignlab2;
import java.util.Scanner;
public class MainClass24 {
	public static void main(String[] args) {
		System.out.println("Person Details");
		System.out.println("----------------------------------");
		System.out.println("Enter FirstName,LastName,PhoneNumber,Age,Weight,Gender...");
		new MethodsToGet().DisplayDetails();
	}

}
