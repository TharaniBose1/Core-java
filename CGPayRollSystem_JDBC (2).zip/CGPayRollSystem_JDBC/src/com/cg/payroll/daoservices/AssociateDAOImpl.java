package com.cg.payroll.daoservices;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class AssociateDAOImpl implements AssociateDAO {
	@Override
	public Associate save(Associate associate) {
		return null;
	}

	@Override
	public boolean update(Associate associate) {	
		return false;
	}
	@Override
	public Associate findOne(int associateId) throws AssociateDetailsNotFoundException {
		return null;
	}
	@Override
	public List<Associate> findAll() {
				return null;
	}
	
}
