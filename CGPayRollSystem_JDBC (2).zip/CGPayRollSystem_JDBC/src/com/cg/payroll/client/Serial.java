package com.cg.payroll.client;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.util.PayrollUnit;
class Serial extends PayrollUnit {
	@SuppressWarnings("unchecked")
	public static  HashMap<Integer, Associate> deSerialization(String string) throws FileNotFoundException, IOException, ClassNotFoundException {
		HashMap<Integer, Associate> hashmapob=null;
		try(ObjectInputStream objectToRead=new ObjectInputStream(new BufferedInputStream( new FileInputStream(string)))){
			hashmapob=(HashMap<Integer, Associate>)objectToRead.readObject();
		return  hashmapob;
	}
	}
public static void serialization(String string, HashMap<Integer, Associate> associates) throws FileNotFoundException,IOException {
	try(ObjectOutputStream destWriter=new ObjectOutputStream(new BufferedOutputStream(new  FileOutputStream(string)))){
		destWriter.writeObject(PayrollUnit.associates);
		destWriter.close();
		System.out.println("File has been created in loctaion");	
	} 
}
}

