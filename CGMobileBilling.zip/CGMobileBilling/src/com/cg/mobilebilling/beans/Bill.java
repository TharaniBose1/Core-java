package com.cg.mobilebilling.beans;
public class Bill {
	private int noOfLocalSMS,noOfStdSMS,noOfLocalCalls,noOfStdCalls,internetDataUsageUnitsAmount,totalBillAmount,localSMSAmount,stdSMSAmount,localCallAmount;
	private float stateGST,centralGST,internetDataUsageUnits;
	private String billID,billMonth;
	public Bill() {
		// TODO Auto-generated constructor stub
	}
	public int getNoOfLocalSMS() {
		return noOfLocalSMS;
	}
	public void setNoOfLocalSMS(int noOfLocalSMS) {
		this.noOfLocalSMS = noOfLocalSMS;
	}
	public int getNoOfStdSMS() {
		return noOfStdSMS;
	}
	public void setNoOfStdSMS(int noOfStdSMS) {
		this.noOfStdSMS = noOfStdSMS;
	}
	public int getNoOfLocalCalls() {
		return noOfLocalCalls;
	}
	public void setNoOfLocalCalls(int noOfLocalCalls) {
		this.noOfLocalCalls = noOfLocalCalls;
	}
	public int getNoOfStdCalls() {
		return noOfStdCalls;
	}
	public void setNoOfStdCalls(int noOfStdCalls) {
		this.noOfStdCalls = noOfStdCalls;
	}
	public int getInternetDataUsageUnitsAmount() {
		return internetDataUsageUnitsAmount;
	}
	public void setInternetDataUsageUnitsAmount(int internetDataUsageUnitsAmount) {
		this.internetDataUsageUnitsAmount = internetDataUsageUnitsAmount;
	}
	public int getTotalBillAmount() {
		return totalBillAmount;
	}
	public void setTotalBillAmount(int totalBillAmount) {
		this.totalBillAmount = totalBillAmount;
	}
	public int getLocalSMSAmount() {
		return localSMSAmount;
	}
	public void setLocalSMSAmount(int localSMSAmount) {
		this.localSMSAmount = localSMSAmount;
	}
	public int getStdSMSAmount() {
		return stdSMSAmount;
	}
	public void setStdSMSAmount(int stdSMSAmount) {
		this.stdSMSAmount = stdSMSAmount;
	}
	public int getLocalCallAmount() {
		return localCallAmount;
	}
	public void setLocalCallAmount(int localCallAmount) {
		this.localCallAmount = localCallAmount;
	}
	public float getStateGST() {
		return stateGST;
	}
	public void setStateGST(float stateGST) {
		this.stateGST = stateGST;
	}
	public float getCentralGST() {
		return centralGST;
	}
	public void setCentralGST(float centralGST) {
		this.centralGST = centralGST;
	}
	public float getInternetDataUsageUnits() {
		return internetDataUsageUnits;
	}
	public void setInternetDataUsageUnits(float internetDataUsageUnits) {
		this.internetDataUsageUnits = internetDataUsageUnits;
	}
	public String getBillID() {
		return billID;
	}
	public void setBillID(String billID) {
		this.billID = billID;
	}
	public String getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}
	

}
