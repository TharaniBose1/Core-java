package com.cg.attendencesystem.util;
import java.util.HashMap;
import com.cg.attendencesystem.beans.Student;
public class AttendenceSystemUtil {
public static int student_IDCounter;
public static HashMap<Integer, Student> associateOfMap=new HashMap<>();
public static int getStudent_IDCounter() {
	return ++student_IDCounter;
}
}
