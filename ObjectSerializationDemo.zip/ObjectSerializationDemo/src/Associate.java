import java.io.Serializable;
public class Associate implements Serializable{
	private int basicSalary;
	private transient int netSalary;
	private String firstName,lastName;
	public Associate() {}
	public Associate(int basicSalary, int netSalary, String firstName, String lastName) {
		super();
		this.basicSalary = basicSalary;
		this.netSalary = netSalary;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public int getNetSalary() {
		return netSalary;
	}
	public void setNetSalary(int netSalary) {
		this.netSalary = netSalary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "Associate [basicSalary=" + basicSalary + ", netSalary=" + netSalary + ", firstName=" + firstName
				+ ", lastName=" + lastName + "]";
	} 
	
}
