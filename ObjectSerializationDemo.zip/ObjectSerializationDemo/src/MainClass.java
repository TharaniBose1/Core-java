import java.io.File;
import java.io.IOException;
public class MainClass {
	public static void main(String[] args) {
		try {
			File file=new File("D:\\AssociateData.txt");
			ObjectSerializatoinDemo.doSerialization(file);
			ObjectSerializatoinDemo.doDeSerialization(file);
		} catch (IOException | ClassNotFoundException e) {
			
			e.printStackTrace();
		}

	}

}
