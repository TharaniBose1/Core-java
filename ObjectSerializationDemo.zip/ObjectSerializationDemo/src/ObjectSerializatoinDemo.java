import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

public class ObjectSerializatoinDemo {

public static  void doSerialization(File file) throws FileNotFoundException, IOException {
	Associate associate=new Associate(7000, 20000, "Tharani", "Bose");
	try(ObjectOutput destWriter=new ObjectOutputStream(new FileOutputStream(file))){
		destWriter.writeObject(associate);
		System.out.println("Associate Details serailzedOutput"+file.getAbsolutePath());	
	}
	
}
public static void doDeSerialization(File file) throws FileNotFoundException, IOException, ClassNotFoundException {
	try(ObjectInputStream srcReader=new ObjectInputStream(new FileInputStream(file))){
		Object associate=(Object) srcReader.readObject();
		System.out.println(associate);
		System.out.println("Associate Details deserailzedOutput"+file.getAbsolutePath());
	}
}

}
