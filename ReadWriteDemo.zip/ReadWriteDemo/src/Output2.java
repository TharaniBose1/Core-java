import java.nio.file.Path;
import java.nio.file.Paths;

public class Output2 {
	public static void main(String[] args) {
		
			Path javaHome = Paths.get("C:/Java/jdk1.8.0_25");
			  System.out.println(javaHome.getNameCount());
			
	
}

}
