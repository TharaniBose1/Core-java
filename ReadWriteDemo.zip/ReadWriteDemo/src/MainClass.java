import java.io.File;
import java.io.IOException;

public class MainClass {
	public static void main(String[] args) {
		try {
			File fromFile=new File("D:\\Users\\ADM-IG-HWDLAB2E\\file\\newtxt.txt");
			 File toFile=new File("D:\\"+fromFile.getName());
			 ReadWriteDemo.characterReadWrite(fromFile, toFile); 
			 ReadWriteDemo.characterReadWrite(fromFile, toFile); 
		}
catch(IOException e) {
	e.printStackTrace();
}
	}

}
