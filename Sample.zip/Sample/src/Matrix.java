
public class Matrix {
	public static void main(String[] args) {
	int [][][] numList=new int[][][] {{{10,20,30},{40,50,60},{70,80,90}}};
	for(int i=0;i<numList.length;i++) {
		for(int j=0;j<numList[i].length;j++) {
			for(int k=0;k<numList[i][j].length;k++) {
				System.out.println(numList[i][j][k]);				
		             	       }		
              }
  	  }
   }
}
