
public class Sample {
	int num1,num2;
	private static int num3;
	public static void main(String[] args) {
		Sample ex1=new Sample(10,20);
        Sample ex2=new Sample(30,40);
       Sample ex3=new Sample(50,60);
       ex1.incre();
       ex2.incre();
       ex3.incre();
	}
	public Sample(int num1, int num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
		
	}
	void incre() {
		num1++;
		num2++;
		num3++;
		
		System.out.println(num1+" "+num2+" "+num3);
		
	}
	
	
	

}
