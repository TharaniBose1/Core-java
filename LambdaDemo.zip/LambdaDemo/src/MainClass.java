public class MainClass {
	public static void main(String[] args) {
//FunctionInterface1 ref1=(firstN,lastN)->System.out.println("Good morning   "+firstN+"  DT"+lastN);
//ref1.greetUser("Tharani", "Bose");
//FunctionInterface2 ref2=(a,b)->a+b ;
//System.out.println(ref2.add(10, 20));
//	FunctionInterface3 ref3= (s)->s.toUpperCase();
//	System.out.println(ref3.toUpperCase("tharani bose"));
		callForWork(()->System.out.println("Doing some work"));
	}
	public static void callForWork(WorkInteface worksService) {
	worksService.doSomeWork();
}
}