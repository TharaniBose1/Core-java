public interface FunctionInterface1 {
public void greetUser(String firstName,String lastName);
}
