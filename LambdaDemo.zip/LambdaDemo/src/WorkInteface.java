
public interface WorkInteface {
public void doSomeWork();
}
