public interface FunctionInterface2 {
public int add(int num1,int num2);
}
