public interface FunctionInterface3 {
public String toUpperCase(String str);
}
