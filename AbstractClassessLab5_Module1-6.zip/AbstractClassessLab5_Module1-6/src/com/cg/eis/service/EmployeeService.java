package com.cg.eis.service;

import com.cg.eis.exceptions.SalaryBelowException;

public interface EmployeeService {
	public String determineScheme(long Salary,String designation) throws SalaryBelowException;
}
