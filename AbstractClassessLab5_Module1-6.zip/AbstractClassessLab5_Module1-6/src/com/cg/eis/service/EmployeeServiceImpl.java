package com.cg.eis.service;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import com.cg.eis.bean.Employee;
import com.cg.eis.exceptions.SalaryBelowException;
public class EmployeeServiceImpl implements EmployeeService {
	@Override
	public String determineScheme(long Salary,String designation) throws SalaryBelowException {
		if(Salary<=3000) throw new SalaryBelowException("	BELOW 3000");
		String scheme=new String();
		if((Salary>5000 && Salary<20000)&& designation.equals("System Associate")) {
			scheme="Scheme C";
			return scheme;
		}
		else if((Salary>20000 && Salary<40000)&& designation.equals("Programmer")) {
			scheme="Scheme B";
			return scheme;
		}
		else if((Salary>=40000)&&designation.equals("Manager")) {
			scheme="Scheme A";
			return scheme;
		}
		else if((Salary<5000)) {
			scheme="No scheme is found";
			return scheme;
		}
		return null;
	}
	public static void serialization(String string,Employee e) throws FileNotFoundException,IOException {
		try(ObjectOutputStream destWriter=new ObjectOutputStream(new BufferedOutputStream(new  FileOutputStream(string)))){
			destWriter.writeObject(e);
			destWriter.close();
			System.out.println("File has been created in loctaion");	
		} 
	}
	public static  Employee deSerialization(String string) throws FileNotFoundException, IOException, ClassNotFoundException {
		Employee empObj=null;
		try(ObjectInputStream objectToRead=new ObjectInputStream(new BufferedInputStream( new FileInputStream(string)))){
		 empObj=(Employee) objectToRead.readObject();
			System.out.println(empObj);
		return  empObj;
	}
 
}}