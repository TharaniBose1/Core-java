package com.cg.inheritancedemosa.client;
import com.cg.inheritancedemosa.beans.*;
public class MainClass {
	public static void main(String[] args) {
		FlightBook fgob1;
		fgob1=new DomesticPass("Tharani", "Bose", "Chennai", "Pune", 54265, 200, "Airport45", 10,673);
		DomesticPass doob1=(DomesticPass)fgob1;
		doob1.CheckGovtIdVerify();
		System.out.println(fgob1.getTotalCharge());	
				
				
				
	
	}
}
