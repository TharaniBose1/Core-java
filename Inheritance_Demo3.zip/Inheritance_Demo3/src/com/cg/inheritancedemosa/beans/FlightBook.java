package com.cg.inheritancedemosa.beans;

public abstract class FlightBook {
 private String firstName,lastName,startDate,endDate,from,to,passportNo,referAirNo,airportId;
private int govtIdProofNo,noOfPassengers,discount,totalCharge;
public FlightBook() {
}
public FlightBook(String firstName, String lastName, String from, String to, int govtIdProofNo, int discount,String airportId,int noOfPassengers) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.from = from;
	this.to = to;
	this.govtIdProofNo = govtIdProofNo;
	this.discount = discount;
	this.airportId=airportId;
	this.noOfPassengers=noOfPassengers;
}
public FlightBook(String firstName, String lastName, String from, String to, String passportNo, int govtIdProofNo,
		int discount,String airportId) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.from = from;
	this.to = to;
	this.passportNo = passportNo;
	this.govtIdProofNo = govtIdProofNo;
	this.discount = discount;
	this.airportId=airportId;
}

public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getEndDate() {
	return endDate;
}
public void setEndDate(String endDate) {
	this.endDate = endDate;
}
public String getFrom() {
	return from;
}
public void setFrom(String from) {
	this.from = from;
}
public String getTo() {
	return to;
}
public void setTo(String to) {
	this.to = to;
}
public String getPassportNo() {
	return passportNo;
}
public void setPassportNo(String passportNo) {
	this.passportNo = passportNo;
}
public int getGovtIdProofNo() {
	return govtIdProofNo;
}
public void setGovtIdProofNo(int govtIdProofNo) {
	this.govtIdProofNo = govtIdProofNo;
}
public int getNoOfPassengers() {
	return noOfPassengers;
}
public void setNoOfPassengers(int noOfPassengers) {
	this.noOfPassengers = noOfPassengers;
}
public int getDiscount() {
	return discount;
}
public void setDiscount(int discount) {
	this.discount = discount;
}
public int getTotalCharge() {
	return totalCharge;
}
public void setTotalCharge(int totalCharge) {
	this.totalCharge = totalCharge;
}

public String getReferAirNo() {
	return referAirNo;
}
public void setReferAirNo(String referAirNo) {
	this.referAirNo = referAirNo;
}
public String getAirportId() {
	return airportId;
}
public void setAirportId(String airportId) {
	this.airportId = airportId;
}
public FlightBook(String referAirNo) {
	super();
	this.referAirNo = referAirNo;
}
abstract void generateReferenceId();
}
