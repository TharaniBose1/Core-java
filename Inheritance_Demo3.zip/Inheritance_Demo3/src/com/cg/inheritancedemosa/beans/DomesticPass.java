package com.cg.inheritancedemosa.beans;
public class DomesticPass extends FlightBook {
	private int taxDomestic,total;
	String airBookId,referAirId;
	public DomesticPass() {
		// TODO Auto-generated constructor stub
	}
	public void CheckGovtIdVerify(){
		System.out.println("Submitted");
	}
	public DomesticPass(String firstName, String lastName, String from, String to, int govtIdProofNo, int discount,
			String airportId, int noOfPassengers,int taxDomestic) {
		super(firstName, lastName, from, to, govtIdProofNo, discount, airportId, noOfPassengers);
		this.taxDomestic=taxDomestic;
	}
	public	void generateReferenceId() {
		
		}
	public int getTaxDomestic() {
		return taxDomestic;
	}
	public void setTaxDomestic(int taxDomestic) {
		this.taxDomestic = taxDomestic;
	}
	public String getAirBookId() {
		return airBookId;
	}
	public void setAirBookId(String airBookId) {
		this.airBookId = airBookId;
	}
	
	
	
	

}
