package com.cg.inheritancedemosa.beans;
public class InterNationalPass extends FlightBook{
	private String airInterId;
	public InterNationalPass() {
		// TODO Auto-generated constructor stub
	}
	public	void generateReferenceId() {
		this.airInterId=getFirstName()+getPassportNo();
		this.setAirportId(this.airInterId);		
		}
}
