package com.cg.payroll.client;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.InvalidEmailException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollUnit;
public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotFoundException, InterruptedException {
		/*RunnableRes res=new RunnableRes();
Thread th1=new Thread(res, "Thread1");
th1.start();*/
		/*Thread th2=new Thread(res,"Thread2");
th2.start();*/
		/*Runtime r=Runtime.getRuntime();  
r.addShutdownHook(th1); */ 
		PayrollServices payrollServices=new PayrollServicesImpl();
		/*
		for (Associate associate : associates) {
			if(associate.getAssociateID()==111)
				System.out.println(associate.getFirstName()+"  "+associate.getLastName());		
		}
		 */
		/*Associate []associates =new Associate[5];
associates[0]=new Associate(111, 520000, "Thara", "Bose","IT","A4","HKF7347Q", "tharani@gmail.com",new Salary(16000, 500, 1200),new BankDetails(476757, "ICICFI", "icici62742"));
associates[1]=new Associate(112, 169100, "Raja", "Rakesh","IT","A4","HKF7347Q", "tharani@gmail.com",new Salary(26000, 500, 1200),new BankDetails(476757, "HDFC", "hdfc14352"));
associates[2]=new Associate(113, 118200, "Rani", "Kanni","IT","A4","HKF7347Q", "tharani@gmail.com",new Salary(86000, 500, 1200),new BankDetails(476757, "HDFC", "hdfc62742"));
associates[3]=new Associate(114, 720000, "Karthi", "Sanithiya","IT","A4","HKF7347Q", "tharani@gmail.com",new Salary(96000, 500, 1200),new BankDetails(476757, "SBI", "sbin62742"));
associates[4]=new Associate(115, 50000, "Ambikai", "Elizil","IT","A4","HKF7347Q", "tharani@gmail.com",new Salary(56000, 500, 1200),new BankDetails(476757, "SBI", "sbin62742"));	
for (Associate associate : associates) {
	System.out.println(associate.getAssociateID()+" "+associate.getFirstName()+" "+associate.getLastName());;
	if((associate.getSalary().getBasicSalary()>=20000) && (associate.getBankDetails().getBankName()=="HDFC")) 
		 */	
/*System.out.println("eNTER CHOICE 0 or -1 to exit");
		Scanner s=new Scanner(System.in);
		int ch=s.nextInt();
			switch(ch)
			{
			case 0:
			{
				System.out.println("Enter Invesement");
			int yearlyInverstmentUnder80C=s.nextInt();
			System.out.println("Enter First Name");
			String firstName=s.next();	
			System.out.println("Enter Last Name");
			String lastName=s.next();
			System.out.println("Enter department");
			String department=s.next();
			System.out.println("Enter designation");
			String designation=s.next();
			System.out.println("EnterPAN NAME");
			String pancard=s.next();	
			System.out.println("Enter EMIAL ID");
			String emailId=s.next();	
			System.out.println("BASIC SALRY");
			int basicSalary=s.nextInt();
			System.out.println("epf");
			int epf=s.nextInt();
			System.out.println("companypf");
			int companyPf=s.nextInt();
			System.out.println("accout no");
			int accountNumber=s.nextInt();
			String bankName=s.next();
			String ifscCode=s.next();
				int AssocId;
				try {
					AssocId = payrollServices.acceptAssociateDetails(yearlyInverstmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
					System.out.println("Generated id"+AssocId);
				
				} catch (InvalidEmailException e) {
					e.printStackTrace();
				}	
					break;
			}
			default:
				System.out.println("Thanks for viewing us");
                break;
			}		
		
		*/
		try {
			@SuppressWarnings("unchecked")
			/*HashMap<Integer,Associate> has=PayrollUnit.deSerialization("fileToSave.txt");
			ArrayList< Associate> associates =new ArrayList<>(has.values());
			associates.forEach(e->System.out.println("Values Retained are "+e.getAssociateID()));
			for (Associate associate : associates) {
				System.out.println("Values that has been retained :    "+associate.getAssociateID());
			}*/
			int accociateId1=payrollServices.acceptAssociateDetails(5000, "Tharani", "Bose", "IT", "analyst", "FHA612GF", "thara@gmail.com", new Salary(50000, 1000, 1000), new BankDetails(121324325, "HDFC", "hdfc26564g"));
			System.out.println("GENETRRATED ID IS"+accociateId1);
		//	payrollServices.acceptAssociateDetails(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, salary, bankDetails);
		//	int accociateId2=payrollServices.acceptAssociateDetails(2000, "Karthiyayini", "P", "IT", "Data Analyst", "AF60154KL", "kaKrthi@gmail.com", new Salary(5000, 1500, 1200), new BankDetails(13001212, "HDFC", "hdfc30458g"));
			/*System.out.println("GENETRRATED ID IS"+accociateId2);
			int accociateId3=payrollServices.acceptAssociateDetails(1000, "Rakesh", "P", "MECH", "Mainatance Engineer", "HYFD478N", "rakesh@gmail.com", new Salary(9000, 1500, 1200), new BankDetails(239897120, "ICICI", "icici2454s'"));
			System.out.println("GENETRRATED ID IS"+accociateId3);
			PayrollUnit.serialization("fileToSave.txt", PayrollUnit.associates);	
			Associate associate2=payrollServices.getAssociateDetails(101);
			System.out.println("Associate id:"+associate2.getAssociateID()+"And their first name is"+associate2.getFirstName()+"HRA  "+PayrollUnit.associates.get(associate2));
			//System.out.println(object.toString());
*/			int calculatedNetSalary1=payrollServices.calculateNetSalary(accociateId1);
			System.out.println("Calculate Salary:"+calculatedNetSalary1);
			/*int calculatedNetSalary2=payrollServices.calculateNetSalary(102);
			Associate associate21=payrollServices.getAssociateDetails(101);
			System.out.println("fOUND"+associate21.getAssociateID());
			System.out.println("Calculate Salary:"+calculatedNetSalary2);
			for (Entry<Integer, Associate> entry : PayrollUnit.associates.entrySet()) {
				Integer key = entry.getKey();
				Associate tab = entry.getValue();
				int hra =tab.getSalary().getHra();
				System.out.println(key+"SPACE "+hra);
			}*/
		} catch (Exception e) {
			e.printStackTrace();
		}	
		/*Associate associate2=payrollServices.getAssociateDetails(101);
		System.out.println("Associate id:"+associate2.getAssociateID()+"And their first name is"+associate2.getFirstName());
		List< Associate> arrayList;
		arrayList=payrollServices.getAllAssociatesDetails();
		for (Associate associate : arrayList) {
			System.out.println(associate.getAssociateID());
		 */

	}

}





