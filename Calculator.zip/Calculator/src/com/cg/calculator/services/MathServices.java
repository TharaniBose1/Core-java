package com.cg.calculator.services;

import com.cg.calculator.exceptions.InvalidNumberRangeException;

public interface MathServices {
int add(int a,int b)throws InvalidNumberRangeException;
int sub(int a,int b)throws InvalidNumberRangeException;
int mul(int a,int b)throws InvalidNumberRangeException;
int div(int a,int b)throws InvalidNumberRangeException;
}
