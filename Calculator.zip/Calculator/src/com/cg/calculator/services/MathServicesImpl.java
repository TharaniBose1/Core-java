package com.cg.calculator.services;

import com.cg.calculator.exceptions.InvalidNumberRangeException;

public class MathServicesImpl implements MathServices{

	@Override
	public int add(int a, int b) throws InvalidNumberRangeException{
		if(a<0 || b<0)
			 throw new  InvalidNumberRangeException();
		
		return a+b;
		
	}

	@Override
	public int sub(int a, int b) throws InvalidNumberRangeException {
		if(a<0 ||  b<0 ||  a<b)throw new InvalidNumberRangeException();
			
		return a-b;
	}

	@Override
	public int mul(int a, int b) throws InvalidNumberRangeException{
		if(a<0 || b<0) throw new InvalidNumberRangeException();
		return a*b;
	}

	@Override
	public int div(int a, int b)throws InvalidNumberRangeException {
	if(a<0|| b<=0)throw new InvalidNumberRangeException();
		return a/b;
	}

}
