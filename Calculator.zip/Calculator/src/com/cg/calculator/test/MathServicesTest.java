package com.cg.calculator.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.calculator.exceptions.InvalidNumberRangeException;
import com.cg.calculator.services.MathServices;
import com.cg.calculator.services.MathServicesImpl;

import junit.framework.Assert;

public class MathServicesTest {
private static 	MathServices mathServices;
private int firstInvalidNumber,secondInvalidNumber,firstValidNumber,secondValidNumber;
	@BeforeClass
	public static void setUpEnv() {
	 mathServices=new MathServicesImpl();
	}
	@Before
	public void setUpTestData() {
		firstInvalidNumber=-20;
		secondInvalidNumber=-10;
		firstValidNumber=20;
		secondValidNumber=10;
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddForFirstInvalidNumber()throws InvalidNumberRangeException{
		mathServices.add(firstInvalidNumber, secondValidNumber);
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddForSecondInvalidNumber()throws InvalidNumberRangeException{
		mathServices.add(firstValidNumber, secondInvalidNumber);
	}
	@Test
	public void testAddForBothNumbers()throws InvalidNumberRangeException{
		int expectedAns=30;
		int actualAns=mathServices.add(firstValidNumber, secondValidNumber);
 org.junit.Assert.assertEquals(expectedAns, actualAns);				
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testSubForFirstInvalidNumber()throws InvalidNumberRangeException{
		mathServices.sub(firstInvalidNumber, secondValidNumber);	
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testSubForSecondInvalidNumber()throws InvalidNumberRangeException{
		mathServices.sub(firstValidNumber, secondInvalidNumber);	
	}
	@Test
	public void testSubForBothNumbers()throws InvalidNumberRangeException{
		int expectedAns=10;
		int actualAns=mathServices.sub(firstValidNumber, secondValidNumber);
 org.junit.Assert.assertEquals(expectedAns, actualAns);				
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testMulForFirstInvalidNumber()throws InvalidNumberRangeException{
		mathServices.mul(firstInvalidNumber, secondValidNumber);	
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testMulForSecondInvalidNumber()throws InvalidNumberRangeException{
		mathServices.mul(firstValidNumber, secondInvalidNumber);	
	}
	@Test
	public void testMulForBothNumbers()throws InvalidNumberRangeException{
		int expectedAns=200;
		int actualAns=mathServices.mul(firstValidNumber, secondValidNumber);
 org.junit.Assert.assertEquals(expectedAns, actualAns);				
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testDivForFirstInvalidNumber()throws InvalidNumberRangeException{
		mathServices.div(firstInvalidNumber, secondValidNumber);	
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testDivForSecondInvalidNumber()throws InvalidNumberRangeException{
		mathServices.div(firstValidNumber, secondInvalidNumber);	
	}
	@Test
	public void testDivForBothNumbers()throws InvalidNumberRangeException{
		int expectedAns=2;
		int actualAns=mathServices.div(firstValidNumber, secondValidNumber);
 org.junit.Assert.assertEquals(expectedAns, actualAns);				
	}
	@AfterClass
	public static void tearDownEnv() {
		mathServices=null;
	}

	}

	

