package com.cg.calculator.exceptions;

public class InvalidNumberRangeException extends Exception {

}
