package com.cg.calculator.cilent;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.calculator.exceptions.InvalidNumberRangeException;
import com.cg.calculator.services.MathServices;
import com.cg.calculator.services.MathServicesImpl;
public class MainClass {
	public static void main(String[] args) throws InvalidNumberRangeException {
		/*
MathServices msob1=new MathServicesImpl();
System.out.println(msob1.add(12, 10));
System.out.println(msob1.sub(12, 10));
System.out.println(msob1.mul(12, 10));
System.out.println(msob1.div(12, 10));
		 */
		try {
			Scanner st=new Scanner(System.in);
			System.out.println("Enter the first Numner");
			int num1=st.nextInt();
			System.out.println("Enter the second Number");
			int num2=st.nextInt();
			MathServices mathServices=new MathServicesImpl();
		int result1=mathServices.add(num1, num2);
			System.out.println("Result"+ " ="+result1);
		}
		catch (InputMismatchException e) {
			System.err.println("HEY ENTER ONLY NUMBERS");
		}
		catch (ArithmeticException e) {
			System.err.println(e.getMessage()+ " "+"HEY CHECK THE NUMBER NOT TO B ZERO");		}                                                                                                                                                                                                                                                                                                                                                                                   
		System.out.println("The code block after try catch!");
	}
}
