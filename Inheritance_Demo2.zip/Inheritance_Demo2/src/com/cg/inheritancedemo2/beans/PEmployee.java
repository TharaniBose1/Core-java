package com.cg.inheritancedemo2.beans;
public class PEmployee extends Employee {
	public int hra,dra,ta;
	public PEmployee() {
		// TODO Auto-generated constructor stub
	}
	public PEmployee(int hra, int dra, int ta) {
		super();
		this.hra = hra;
		this.dra = dra;
		this.ta = ta;
	}
	public PEmployee(String firstName, String lastName, int basicSalary, int employId) {
		super(firstName, lastName, basicSalary, employId);
		// TODO Auto-generated constructor stub
	}
	
	void calculateSalary() {
		this.hra=getBasicSalary()*10/100;
		this.dra=getBasicSalary()*10/100;
		
	}

	
}
