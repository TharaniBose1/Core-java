package com.cg.inheritancedemo2.beans;
public class Employee {
	private String firstName,lastName;
	private int basicSalary,employId,totalSalary;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(String firstName, String lastName, int basicSalary, int employId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.basicSalary = basicSalary;
		this.employId = employId;
	}
	public Employee(String firstName, String lastName, int employId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.employId = employId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public int getEmployId() {
		return employId;
	}
	public void setEmployId(int employId) {
		this.employId = employId;
	}
	public int getTotalSalary() {
		return totalSalary;
	}
	public void setTotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;
	}
void calculateSalary() {
	totalSalary=basicSalary;
	System.out.println("Hi method from Employee Class");
}
}
