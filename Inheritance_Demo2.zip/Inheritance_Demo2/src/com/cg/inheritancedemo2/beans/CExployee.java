package com.cg.inheritancedemo2.beans;
public class CExployee  extends Employee{
	private int variableSalary,hrs;
	public CExployee() {
		// TODO Auto-generated constructor stub
	}
	public CExployee(String firstName, String lastName, int employId,int hrs) {
		super(firstName, lastName, employId);
	this.hrs=hrs;
	}
	public int getVariableSalary() {
		return variableSalary;
	}
	public void setVariableSalary(int variableSalary) {
		this.variableSalary = variableSalary;
	}
	public int getHrs() {
		return hrs;
	}
	public void setHrs(int hrs) {
		this.hrs = hrs;
	}
	
	

}
