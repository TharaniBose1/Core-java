package com.cg.inheritancedemo2.client;
import com.cg.inheritancedemo2.beans.*;
public class MainClass {
	public static void main(String[] args) {


	}
}
