package com.cg.eis.service;

import com.cg.eis.exceptions.SalaryBelowException;

public class EmployeeServiceImpl implements EmployeeService {
	@Override
	public String determineScheme(long Salary,String designation) throws SalaryBelowException {
		if(Salary<=3000) throw new SalaryBelowException("	BELOW 3000");
		String scheme=new String();
		if((Salary>5000 && Salary<20000)&& designation.equals("System Associate")) {
			scheme="Scheme C";
			return scheme;
		}
		else if((Salary>20000 && Salary<40000)&& designation.equals("Programmer")) {
			scheme="Scheme B";
			return scheme;
		}
		else if((Salary>=40000)&&designation.equals("Manager")) {
			scheme="Scheme A";
			return scheme;
		}
		else if((Salary<5000)) {
			scheme="No scheme is found";
			return scheme;
		}
		return null;

		
	}
 
}
