package com.cg.eis.pl;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exceptions.SalaryBelowException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;
public class MainClass {
	public static void main(String[] args) {
		EmployeeService employeeService=new EmployeeServiceImpl();
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter employee's name,designation,salary");
		String employName=scan.next();
		String designation=scan.next();
		long salary=scan.nextLong();
		Employee employee=new Employee(employName, designation, salary);
		try {
			String schemeForEmployee = employeeService.determineScheme(salary,designation);
			System.out.println("Based on Employee's Salary scheme obtained"+schemeForEmployee);
		} catch (SalaryBelowException e) {            //throws Exception lab 6
		e.printStackTrace();}
		System.out.println("Employee's Name"+employee.getName());
		System.out.println("Employee's Designation"+employee.getDesignation());
		
	}

}
