package com.cg.labassignlab9.files;
import java.io.*;
import java.util.*;
public class ReaderFile {
	public static void main(String[] args) throws IOException,FileNotFoundException
	{   
		FileReader fr=new FileReader("D:\\Users\\ADM-IG-HWDLAB2E\\PayRollQueries1.txt");
		BufferedReader br=new BufferedReader(fr);
		String s;
		List<String> tmp = new ArrayList<String>();
		do{
			s = br.readLine();
			tmp.add(s);
		}while(s!=null);
		for(int i=tmp.size()-1;i>=0;i--) 
			System.out.println(tmp.get(i));
		String tm=tmp.toString();
		DataOutputStream dos= new DataOutputStream(new BufferedOutputStream(new FileOutputStream("D:\\Users\\ADM-IG-HWDLAB2E\\PayRollQueriesOutPut2.txt")));
        for (int i=0;i<tmp.size();i++) {
            String str = tmp.get(i).toString();
            dos.writeUTF(str);    
            if(i < tmp.size()-1)//This prevent creating a blank like at the end of the file**
                dos.writeUTF("\n");
        }
    	System.out.println("File has been reversed and copied into new File");
        dos.close();
		br.close();
		
	}
}

