package com.cg.labassignlab8.billing;
public class ResourceForLock {
	public volatile int flag=1;
}
	/*Scanner scan=new Scanner(System.in);
	@Override
	public void run() {
		Thread cur=Thread.currentThread();
			if( cur.getName().equals("ThreadG")) {			
				while(scan.hasNext()) {
					System.out.println("Enter to be billed again");
	
				try {
					synchronized (lock) {
					int n=scan.nextInt();
					ArrayList<String>arrayList=new ArrayList<>(n);
					System.out.println("Enter the products to be billed");
					Thread.sleep(400);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Products while ThreadG is running:           "+arrayList);
			}}
			else if(cur.getName().equals("ThreadB"))
			{
				System.out.println("Enter the price of the product");
				 int  price=scan.nextInt();
				 try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				 System.out.println("Price"+price);
				*/
		
	
	