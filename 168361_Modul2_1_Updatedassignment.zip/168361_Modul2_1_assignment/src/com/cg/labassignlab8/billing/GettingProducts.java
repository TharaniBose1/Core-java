package com.cg.labassignlab8.billing;
public class GettingProducts extends Thread {
ResourceForLock lock;
public GettingProducts(ResourceForLock lock) {
	super();
	this.lock = lock;}
@Override
public void run() {
	synchronized (lock) {
		while(lock.flag!=2) {
			try {
				lock.wait();
			} catch (InterruptedException e) {
								e.printStackTrace();
			}}
		System.out.println("Billing starts since all required number products have been done!");
	}
	
	super.run();
}


}
