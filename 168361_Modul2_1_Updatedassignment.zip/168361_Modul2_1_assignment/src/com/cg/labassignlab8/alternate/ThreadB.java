package com.cg.labassignlab8.alternate;
import java.util.Random;
public class ThreadB  extends Thread{
	ResourceLock lock;
	public ThreadB(ResourceLock lock) {
this.lock=lock;
	}
@Override
public void run() {
	try {
		synchronized (lock) {
	  //It is the number to calculate factorial
			while(lock.flag!=2) {
				lock.wait();}
			 int i,fact=1;  
			  for(i=1;i<=ThreadA.number;i++)
			      fact=fact*i;    
			  System.out.println("Factorial of "+ThreadA.number+" is: "+fact);  
			  Thread.sleep(100);
				lock.flag=1;
				lock.notifyAll();
		}
		
	} catch (Exception e) {
	e.printStackTrace();
	}
	super.run();}
}
