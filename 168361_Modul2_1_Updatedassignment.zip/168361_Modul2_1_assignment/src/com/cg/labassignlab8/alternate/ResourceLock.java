package com.cg.labassignlab8.alternate;
public class ResourceLock {
public volatile int flag=1;
}
