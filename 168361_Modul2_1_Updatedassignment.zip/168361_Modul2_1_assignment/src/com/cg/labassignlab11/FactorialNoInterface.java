package com.cg.labassignlab11;
public interface FactorialNoInterface {
long calculateFact(long number);
}
