package com.cg.labassignlab11;
public interface InterfaceForAuthe {
public final String username="USER";
public final String password="tharanibose";
boolean validate( String username,String password);

}
