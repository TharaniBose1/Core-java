package com.cg.labassignlab11;
public interface CalculatePow {
	void calCulatePower(int num1,int num2);
	
}
