package com.cg.labassginlab3;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;
public class JobNameValidation {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Name which needs to be validated");
		String input=new String(scan.next());
		String pattern="^[a-z0-9._-]{8,10}_job{1}$";
		 Pattern pattern1=Pattern.compile(pattern);
		 Matcher mathces=pattern1.matcher(input);
		 if(mathces.find())
			 System.out.println("Match is Found!");
		 else
			 System.out.println("Match is not Found!");
	}

}
