package com.cg.labassginlab3;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class SortingStringObjects {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of elements to be added!");
		int noOfStrings=scan.nextInt();
		ArrayList<String> arraylist=new ArrayList<>();
		for (int i = 0; i < noOfStrings; i++) {
			String input = scan.next();
			arraylist.add(input);	}
		Comparator<String> assCompator=(e1,e2)->e1.compareTo(e2);
		Collections.sort(arraylist, assCompator);
		System.out.println(arraylist);
				/*if(arraylist.size()%2==1)
			for (int i = 0; i <=arraylist.size()-1 ; i++) {
				if(i<(arraylist.size()/2)+1)
					arraylist.get(i).toUpperCase();
				else
					arraylist.get(i).toLowerCase();	}
		else { 
			for (int i = 0; i <=arraylist.size()-1 ; i++) {
				if(i<arraylist.size()/2)
					arraylist.get(i).toUpperCase();
				else
					arraylist.get(i).toLowerCase();
			}
			System.out.println(arraylist);
		}*/

	}}
