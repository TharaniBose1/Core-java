package com.cg.labassginlab3;
import java.util.Scanner;
public class StringBasedOperation {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter choice 1.stringconcat...2.stringreplace");
		int  choice=scan.nextInt();
		switch (choice) {
		case 1: {
			System.out.print("Enter String For concated itself:");
			StringBuilder str1=new StringBuilder(scan.next());
			System.out.println(str1.append(str1));
			break;	}
		case 2:{
			System.out.println("Enter string which whose odd positions should be replaced by #");
			String str=new String(scan.next());
			char[] arrayCh=str.toCharArray();
			for (int i = 0; i < arrayCh.length; i++) {
				if(i%2!=0) {
					arrayCh[i]='#';
					str+=arrayCh[i];}
				else
					str+=arrayCh[i];		}
			System.out.println("Replaced"+str);
			break;
		}
		case 3:{
			System.out.println("Enter the string to remove the duplicate");
			String str=new String(scan.next());
			String result = "";
			for (int i = 0; i < str.length(); i++) {
				if(!result.contains(String.valueOf(str.charAt(i)))) {
					result += String.valueOf(str.charAt(i));
				}
			}
			System.out.println(result);	
		}
		case 4:{
			System.out.println("Enter string in which odd places should be replaced by to uppercase");
			String str=new String(scan.next());
			StringBuilder sb= new StringBuilder();
			for (int i=0; i<str.length(); i++){ 
				if (i%2==0) 
					sb.append(str.charAt(i));
				else
					sb.append(Character.toUpperCase(str.charAt(i)));}
			System.out.println(sb);
			break;}
		case 5:{
			System.out.println("Enter the string which has to be checked for postive string");
			String str=new String(scan.next());
			boolean flag=true;
			for (int i = 0; i < str.length(); i++) {
				if(Character.compare(str.charAt(i),str.charAt(i+1))>0)
					flag=false;
				break;	
			}
			System.out.println(flag);
			break;
		}
		default:System.out.println("exit");
		break;
		}

	}

}
