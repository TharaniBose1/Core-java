package com.cg.labassignlab4;
public class Account extends Person {
private static long accNum,accNumCounter=102021130;
private double balance;
private Person accHolder;
Account accountob;
public Account() {}
public Account( double balance, Person accHolder) {
	super();
	this.balance = balance;
	this.accHolder = accHolder;
	accNum=accNumCounter+1;
	accNumCounter=accNum;
}
public long getAccNum() {
	return accNum;
}
public void setAccNum(long accNum) {
	Account.accNum = accNum;
}
public long getAccNumCounter() {
	return accNumCounter;
}
public void setAccNumCounter(long accNumCounter) {
	Account.accNumCounter = accNumCounter;
}
public  double getBalance() {
	return balance;
}
public  void setBalance(double balance) {
	this.balance = balance;
}
public Person getAccHolder() {
	return accHolder;
}
public void setAccHolder(Person accHolder) {
	this.accHolder = accHolder;
}
public void deposit(double depositAmount) 
{
  balance += depositAmount;
}
public boolean withdraw(double withdrawAmount)
{
  if (withdrawAmount > balance){    
    System.out.println("Insufficient Funds!!!");
    return false;
  } else {
    balance -= withdrawAmount;
    return true;}}
}
