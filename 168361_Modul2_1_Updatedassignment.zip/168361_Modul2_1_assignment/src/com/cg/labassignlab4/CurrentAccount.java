package com.cg.labassignlab4;
public class CurrentAccount extends Account{
	Account account;
final double  overraftMin=10000;
	@Override
	public boolean withdraw(double withdrawAmount) {
		if(account.getBalance()>overraftMin)
		return super.withdraw(withdrawAmount);
		return false;
	}
	

}
