package com.cg.labassignlab4;
public class MainClass {
	public static void main(String[] args)throws AgeIsNotAcceptedException {
	Account accout1=new Account(2000, new Person("Smith", 25));
	//lab 6 exceptio handling for age
	if(accout1.getAccHolder().getAge()<=15)throw new AgeIsNotAcceptedException("Age should be greater than 15");
	accout1.deposit(2000);
	System.out.println(accout1.getAccHolder().getName()+" "+accout1.getAccNum()+"   "+accout1.getBalance());
Account accout2=new Account(3000, new Person("Kathy", 3));
accout2.withdraw(2000);
System.out.println(accout2.getAccHolder().getName()+" "+accout2.getAccNum()+"   "+accout2.getBalance());
	}	
	}