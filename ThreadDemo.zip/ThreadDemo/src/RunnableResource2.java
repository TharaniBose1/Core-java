
public class RunnableResource2 implements Runnable {

	@Override
	public void run() {
		Thread cur=Thread.currentThread();
		for(int i=1;i<=10;i++) {
			if( i%2==0 && cur.getName().equals("th1")) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("even no is from Thread 1     "+i);
			}
			else if( i%2!=0 && cur.getName().equals("th2")) {
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("odd no is from Thread 2        "+i);
		
			}}
	}

}
//