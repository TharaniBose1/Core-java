
public class RunnableResource implements Runnable {

	@Override
	public void run() {
		Thread cur=Thread.currentThread();
		try {
			if(cur.getName().equals("th1")) {
				for (int i = 1; i < 10; i++) {
					Thread.sleep(500);
					System.out.println("Tick      "+i+"     "+cur.getName());
				} }
			else if(cur.getName().equals("th2"))	{
				
				for (int i = 1; i < 10; i++) {
					System.out.println("Tok       "+i+"    "+cur.getName());
				}
				
			}
		
		}catch (InterruptedException e) {

					e.printStackTrace();
				}



	}

}



